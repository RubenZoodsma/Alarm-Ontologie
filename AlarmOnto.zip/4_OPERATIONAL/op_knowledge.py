"""
op_knowledge.py — knowledge helpers for the operational alarm simulation.

Four responsibilities, kept out of the simulation driver (op_inference.py):

  PARSING     read events, timestamps, durations; group per patient.
  EXTRACTION  load the knowledge base; resolve a label to its AlarmType
              archetype and read the structural knowledge off it; resolve
              type concepts to their scaffold entity IRIs.
  MINTING     build the instance ABox an alarm contributes while active,
              grounding the archetype onto the scaffold entity IRIs.
  INFERENCE   materialise OWL entailments with a real reasoner (owlrl), and
              expose the operation-state facts that persist post-alarm.

The time-advancing simulation itself lives in op_inference.py.
"""

from __future__ import annotations

import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import owlrl
from rdflib import Graph, URIRef, Literal, Namespace
from rdflib.namespace import RDF, RDFS, SKOS, XSD, DCTERMS, OWL

sys.path.append(str(Path(__file__).resolve().parent.parent))
from ontology_tree import derive_class_tree, properties_below, walk_instances

# ── Paths ─────────────────────────────────────────────────────────────────────
#
# 4_OPERATIONAL reads 3_CURATION exclusively — never 1_BASE/2_READOUT directly.
# 3_CURATION's four files are hand-authored and stand for themselves (see
# 3_CURATION/check_delta.py for auditing them against upstream): ontology.ttl
# holds the TBox; vocab.ttl carries what used to be 1_BASE/vocab_base.ttl,
# 2_READOUT/outcome/vocab_generated.ttl, and 2_READOUT/outcome/clinical_vocab.ttl;
# inference.ttl carries what used to be 1_BASE/inference.ttl and
# 2_READOUT/outcome/clinical_axioms.ttl — the bridge axioms (class-level
# owl:hasValue restrictions) that let an alarm's metric reach its physiology,
# and a device reach its therapeutic modality, by entailment. It must be
# loaded into reasoning_static alongside ontology.ttl/vocab.ttl for those
# entailments to fire — it carries no TBox declarations of its own, only
# axioms over concepts the other two already define.

OP_DIR    = Path(__file__).parent
ROOT      = OP_DIR.parent
CUR_DIR   = ROOT / "3_CURATION"
ONTOLOGY  = CUR_DIR / "ontology.ttl"
VOCAB     = CUR_DIR / "vocab.ttl"
INFERENCE = CUR_DIR / "inference.ttl"
CATALOGUE = CUR_DIR / "kg.ttl"
ENTITIES  = OP_DIR / "entities.ttl"
EVENTS    = OP_DIR / "events_data.csv"

# ── Namespaces ────────────────────────────────────────────────────────────────

MDA      = Namespace("http://example.org/model-device-alarm-knowledge#")
ENTITY   = Namespace("http://example.org/model-device-alarm-knowledge/entity/")
SCAFFOLD = Namespace("http://example.org/model-device-alarm-knowledge/scaffold/")
INST     = Namespace("http://example.org/model-device-alarm-knowledge/instance/")
OPSTATE  = Namespace("http://example.org/model-device-alarm-knowledge/vocab/operation-state/")
SNAP     = Namespace("http://example.org/model-device-alarm-knowledge/snapshot/")


def _clean(s) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(s)).strip("_")


def _local(iri) -> str:
    return re.split(r"[#/]", str(iri))[-1]


# ── PARSING ───────────────────────────────────────────────────────────────────

@dataclass
class Event:
    patient: str
    label: str
    device_id: str
    start: datetime
    end: datetime


def parse_ts(s: str) -> datetime:
    return datetime.fromisoformat(str(s).strip())


def parse_duration(s: str) -> timedelta:
    """Minimal ISO-8601 duration parser for PT#H#M#S."""
    m = re.match(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", str(s))
    if not m:
        return timedelta(0)
    h, mi, se = (int(x) if x else 0 for x in m.groups())
    return timedelta(hours=h, minutes=mi, seconds=se)


def load_events(path: Path = EVENTS) -> list:
    df = pd.read_csv(path, sep=";", dtype=str).fillna("")
    df.columns = df.columns.str.strip()
    return [
        Event(r["patientID"].strip(), r["label"].strip(), r["device_id"].strip(),
              parse_ts(r["start"]), parse_ts(r["end"]))
        for _, r in df.iterrows()
    ]


def group_by_patient(events: list) -> dict:
    groups: dict = {}
    for e in events:
        groups.setdefault(e.patient, []).append(e)
    return groups


# ── EXTRACTION ────────────────────────────────────────────────────────────────

@dataclass
class KB:
    reasoning_static: Graph   # TBox + inference + vocabulary + scaffold (ABox context)
    catalogue: Graph          # kg_generated.ttl — the AlarmType archetypes
    type_index: dict          # alarm label  → AlarmType IRI
    scaffold_concepts: set    # concepts declared in the scaffold type catalogue
    window: timedelta         # post-alarm validity (PostAlarmValidScheme)
    tree: dict                # class nesting derived from the ontology
    concept_class: dict       # vocabulary concept → the class it instantiates
    last_wins: set            # every leaf/condition property, any class (see leaf_properties)


def concept_classes(g: Graph) -> dict:
    """
    Map every vocabulary concept to the ontology class it instantiates, via
    mda:instantiatesClass scheme bindings — the same declaration entity_seed.py
    and the readout use, so a node can be classified by what it *is* rather
    than by which property happened to reach it (see nodes_of_class).
    """
    mapping = {}
    for scheme, cls in g.subject_objects(MDA.instantiatesClass):
        for concept in g.subjects(SKOS.inScheme, scheme):
            if (concept, SKOS.topConceptOf, scheme) in g:
                continue          # the scheme's own top concept is scaffolding
            mapping[concept] = cls
    return mapping


def nodes_of_class(kb: KB, g: Graph, cls: URIRef) -> set:
    """
    Every node appearing in `g` (as subject or object) whose vocabulary concept
    instantiates `cls` — classification by concept membership, so a caller
    never needs to name the property that led to the node. A new or renamed
    edge into the same class (e.g. a future direct process→organ-system
    property, see clinical_axioms.ttl §3) is picked up with no code change.
    """
    nodes = {t for triple in g for t in (triple[0], triple[2])}
    return {n for n in nodes if kb.concept_class.get(n) == cls}


def load_kb() -> KB:
    static = Graph()
    for f in (ONTOLOGY, VOCAB, INFERENCE, ENTITIES):
        static.parse(f, format="turtle")

    onto = Graph()
    onto.parse(ONTOLOGY, format="turtle")
    tree = derive_class_tree(onto, MDA.Alarm)

    catalogue = Graph()
    catalogue.parse(CATALOGUE, format="turtle")

    type_index = {
        str(lbl): s
        for s, lbl in catalogue.subject_objects(MDA.hasLabel)
        if (s, RDF.type, MDA.AlarmType) in catalogue
    }

    # The scaffold (entities.ttl) is a TYPE CATALOGUE, not a store of usable
    # particulars — its rows exist only to say "this concept is a legitimate
    # individuated type".  Grounding never reuses a scaffold IRI directly (see
    # sensor_iri/signal_iri): Sensor/Signal belong exclusively to the device/
    # sensor that owns them (mda:hasSensor and mda:producesSignal are declared
    # InverseFunctional in the ontology), so a flat, concept-keyed IRI cannot
    # be their identity without colliding across owners.
    scaffold = Graph()
    scaffold.parse(ENTITIES, format="turtle")
    scaffold_concepts = {
        t for _, t in scaffold.subject_objects(RDF.type)
        if "/vocab/" in str(t)
    }

    dur = next(static.objects(MDA.PostAlarmValidScheme, MDA.postAlarmValidityDuration),
               Literal("PT0S"))
    kb = KB(static, catalogue, type_index, scaffold_concepts,
            parse_duration(str(dur)), tree, concept_classes(static), last_wins=set())
    kb.last_wins = condition_properties(kb)
    return kb


@dataclass
class Archetype:
    """
    One AlarmType archetype, read through the ontology's own nesting.

    The traversal is not written here: `walk_instances` follows the tree derived
    from rdfs:domain/rdfs:range, so a branch added to the ontology is followed
    without touching this class.  Callers ask for a class and a property by IRI
    rather than for a fixed key, which is what keeps this from drifting out of
    step with the blueprint the way a hand-coded path did.
    """
    nodes: dict          # class IRI → node in the catalogue
    catalogue: Graph
    vocab: Graph

    def node(self, cls: URIRef):
        """The archetype's node for a class, if the branch is populated."""
        return self.nodes.get(cls)

    def concept(self, cls: URIRef):
        """
        The vocabulary concept typing that node — its identity.  Recognised by
        an actual skos:Concept declaration, not by a substring of the IRI.
        """
        node = self.nodes.get(cls)
        if node is None:
            return None
        return next((t for t in self.catalogue.objects(node, RDF.type)
                     if (t, RDF.type, SKOS.Concept) in self.vocab), None)

    def value(self, cls: URIRef, prop: URIRef):
        """A leaf property's value on that class's node."""
        node = self.nodes.get(cls)
        if node is None:
            return None
        return next(self.catalogue.objects(node, prop), None)


def archetype_structure(kb: KB, type_iri: URIRef) -> Archetype:
    """
    Read one AlarmType archetype by walking the ontology-derived class tree.

    The archetype is typed mda:AlarmType, which is a subclass of mda:Alarm, so
    the walk starts at the tree's root.
    """
    nodes = walk_instances(kb.catalogue, kb.tree, type_iri, MDA.Alarm)
    return Archetype(nodes, kb.catalogue, kb.reasoning_static)


# ── MINTING ───────────────────────────────────────────────────────────────────

def device_iri(device_id: str) -> URIRef:
    return ENTITY[f"Device_{_clean(device_id)}"]


def patient_iri(patient_id: str) -> URIRef:
    return ENTITY[f"Patient_{_clean(patient_id)}"]


def refining_properties(kb: KB, cls: URIRef) -> list:
    """
    Leaf properties whose domain is `cls` and which are marked
    mda:refinesParticularIdentity: properties whose value distinguishes one
    minted particular of this class from another of the same type under the
    same owner (e.g. a device's pre-ductal vs post-ductal SpO2 sensor), rather
    than describing per-alarm/per-owner state.

    Deliberately NOT mda:refinesUniversalIdentity — that annotation marks
    properties that pre-coordinate into a shared vocabulary concept at the
    2_READOUT layer (e.g. Metric.hasPhase, Device.hasManufacturer), which is a
    different mechanism from folding a value into a grounded particular's IRI.
    The two are not interchangeable; see ontology.ttl's node-kind section.

    Read from the ontology so a new identity-refining column needs no code
    change here.
    """
    return sorted(
        (p for p in kb.reasoning_static.subjects(MDA.refinesParticularIdentity, Literal(True))
         if (p, RDFS.domain, cls) in kb.reasoning_static),
        key=str,
    )


def leaf_properties(kb: KB, cls: URIRef) -> list:
    """
    Concept-valued properties on `cls` that describe a CONDITION rather than
    an identity: rdfs:domain cls, rdfs:range skos:Concept, excluding both
    mda:refinesUniversalIdentity (already implied for free by the node's
    type — see background_graph's docstring on hasManufacturer/hasDeviceType)
    and mda:refinesParticularIdentity (identity, handled by
    refining_properties/the minted IRI itself, not by this function).

    This is the generic counterpart to refining_properties: given any node
    the archetype minted, grounding its condition means reading every
    property this returns off the archetype and asserting it — see
    ground_leaf_properties. A new condition-carrying column (a future
    hasCableOperationState, say) needs an ontology declaration only, no
    change here or at any call site.
    """
    return sorted(
        (p for p in kb.reasoning_static.subjects(RDFS.domain, cls)
         if (p, RDF.type, OWL.ObjectProperty) in kb.reasoning_static
         and (p, RDFS.range, SKOS.Concept) in kb.reasoning_static
         and (p, MDA.refinesUniversalIdentity, Literal(True)) not in kb.reasoning_static
         and (p, MDA.refinesParticularIdentity, Literal(True)) not in kb.reasoning_static),
        key=str,
    )


def condition_properties(kb: KB) -> set:
    """
    Every property leaf_properties would return, for ANY class — the full
    set of single-valued condition properties a per-alarm condition graph can
    carry, regardless of which node kind they land on (Metric, Signal,
    Sensor, Component, Device, ...). Used to decide LAST_WINS on merge (see
    merge_conditions): each describes a node's current condition, not an
    accumulating fact, so a later alarm's value overwrites an earlier one on
    the same subject. Computed once from the ontology (see KB.last_wins) so a
    new condition property on any class is covered without touching this
    file.
    """
    domains = {d for d in kb.reasoning_static.objects(None, RDFS.domain) if isinstance(d, URIRef)}
    return {p for cls in domains for p in leaf_properties(kb, cls)}


def ground_leaf_properties(g: Graph, kb: KB, arch, cls: URIRef, node) -> None:
    """Assert every leaf_properties(kb, cls) value the archetype supplies onto `node`."""
    if node is None:
        return
    for prop in leaf_properties(kb, cls):
        value = arch.value(cls, prop)
        if value is not None:
            g.add((node, prop, value))


def resolve_particular_identities(kb: KB, cls: URIRef, events: list) -> tuple:
    """
    For every (device_id, concept) pair `cls`'s occurrences reference across
    `events`, decide whether every refinement dict witnessed for it may be
    safely merged into one grounded particular.

    Two mentions merge if they never assert DIFFERENT values for the same
    refining property (refining_properties, i.e. mda:refinesParticularIdentity)
    — one mention lacking a value never conflicts with another supplying it,
    so a bare 'PulseOximeter_sensor' mention and a 'PulseOximeter_sensor' +
    postDuctal mention merge, taking the UNION of every (property, value)
    pair witnessed as the resolved identity (not just the most-specific
    single mention — two mentions could each supply a different property
    and only jointly describe the one sensor fully).

    A genuine conflict — two DIFFERENT explicit values for the same
    property anywhere in the group, e.g. postDuctal vs preDuctal — means
    there really are (at least) two particulars. The WHOLE (device_id,
    concept) group then falls back to today's behaviour instead: identity
    stays keyed on each occurrence's own exact refinement tuple, no
    merging at all, including for any unrefined mention — it is never
    guessed onto one of the conflicting variants, since nothing in the
    data says which one it belongs to.

    `events` must be one device's (or one patient's) FULL event history,
    never a subset of a single tick — resolving from a partial view would
    make the merge decision depend on which alarms happen to be active at
    that instant, which must not affect a device's identity.

    Returns ({(device_id, concept): refinements}, [(device_id, concept,
    property, {conflicting values})]): the dict covers only safely-merged
    groups — a caller falls back to computing its own event's exact tuple
    for any (device_id, concept) absent from it; the list is for reporting
    (op_inference.py / op_visual.py print it as a [WARN]).
    """
    refiners = refining_properties(kb, cls)
    by_key = defaultdict(list)
    for ev in events:
        type_iri = kb.type_index.get(ev.label)
        if type_iri is None:
            continue
        arch = archetype_structure(kb, type_iri)
        concept = arch.concept(cls)
        if concept is None:
            continue
        refinements = {p: v for p in refiners if (v := arch.value(cls, p)) is not None}
        by_key[(ev.device_id, concept)].append(refinements)

    resolved, conflicts = {}, []
    for key, dicts in by_key.items():
        values_by_prop = defaultdict(set)
        for d in dicts:
            for p, v in d.items():
                values_by_prop[p].add(v)
        conflicting = {p: vs for p, vs in values_by_prop.items() if len(vs) > 1}
        if conflicting:
            for p, vs in sorted(conflicting.items(), key=lambda kv: str(kv[0])):
                conflicts.append((*key, p, vs))
        else:
            resolved[key] = {p: next(iter(vs)) for p, vs in values_by_prop.items()}
    return resolved, conflicts


def _refined_suffix(concept: URIRef, refinements: dict) -> str:
    suffix = _local(concept)
    for prop in sorted(refinements or {}, key=str):
        suffix += f"_{_local(refinements[prop])}"
    return suffix


def sensor_iri(device_id: str, sensor_concept: URIRef, refinements: dict = None) -> URIRef:
    """
    A device's sensor, keyed by its owning device and, where the archetype
    supplies one, its identity-refining property values (refining_properties)
    — so two sensors of the same type on one device, told apart only by e.g.
    anatomical position, mint as two distinct particulars rather than one
    shared node carrying both (contradictory) positions.

    mda:hasSensor is owl:InverseFunctionalProperty: a sensor is reached by at
    most one device.  The IRI must therefore be a function of (device, type,
    refining values), never of type alone — a flat, concept-keyed IRI would be
    claimed by every device that has a sensor of this type, which is exactly
    the identity an InverseFunctionalProperty forbids.
    """
    return ENTITY[f"Sensor_{_clean(device_id)}_{_refined_suffix(sensor_concept, refinements)}"]


def signal_iri(device_id: str, sensor_concept: URIRef, signal_concept: URIRef,
               refinements: dict = None) -> URIRef:
    """
    A sensor's signal, keyed by the specific sensor particular that produces
    it (mereologically: Signal's owner is Sensor, not Device directly, so it
    inherits the same refinement suffix sensor_iri would use for that sensor).
    mda:producesSignal is owl:InverseFunctionalProperty: a signal has at most
    one producing sensor, so its identity must be scoped the same way.
    """
    return ENTITY[f"Signal_{_clean(device_id)}_{_refined_suffix(sensor_concept, refinements)}"
                  f"_{_local(signal_concept)}"]


def component_iri(device_id: str, component_concept: URIRef, refinements: dict = None) -> URIRef:
    """
    A device's non-sensing component, keyed the same way sensor_iri is:
    mda:hasComponent is owl:InverseFunctionalProperty, so identity must be a
    function of (device, type, refining values), never of type alone.
    """
    return ENTITY[f"Component_{_clean(device_id)}_{_refined_suffix(component_concept, refinements)}"]


def alarm_iri(device_id: str, start: datetime) -> URIRef:
    return INST[f"Alarm_{_clean(device_id)}_{start.strftime('%Y%m%dT%H%M%S')}"]


def message_iri(device_id: str, start: datetime) -> URIRef:
    return INST[f"Msg_{_clean(device_id)}_{start.strftime('%Y%m%dT%H%M%S')}"]


def background_graph(kb: KB, events: list, sensor_identity: dict = None,
                      component_identity: dict = None) -> Graph:
    """
    The persistent merge anchors — the shared blocks alarms reason and merge
    over, stated once: the patient (identified) and the device's
    characteristics (its sensors and other components, their placement, and
    the signals the sensors produce), typed and minted from `device_id` alone.

    Deliberately NOT mda:isMonitoredBy: a device's own identity and
    composition (its type, its sensors) is timeless background knowledge, but
    which patient it is currently monitoring is not — the same physical
    device can serve different patients at different times (see
    events_seed.py's device pool). mda:isMonitoredBy is now declared
    owl:InverseFunctionalProperty (a device monitors at most one patient at a
    time), so asserting it here — once, into the persistent background that
    op_inference.py writes to the shared default graph — would put two
    patients who ever shared a device permanently in the same graph, which
    the reasoner would then correctly (and unhelpfully) read as evidence
    they are the same individual. It is asserted per-tick instead, scoped to
    only the alarms actually active at that instant — see
    Timeline.situation_at.

    The device's manufacturer/model are NOT asserted here as separate triples.
    hasManufacturer and hasDeviceType are mda:refinesUniversalIdentity, so the
    archetype's Device node — and therefore `device_type` below — is already
    typed by a pre-coordinated concept (e.g. device:PhysiologicalMonitor_
    Philips, see vocab_readout.py's precoordinate()) whose OWL definition
    entails both facts on any instance of that type. Asserting them again
    here would duplicate what the type already gives for free — precisely
    what clinical_axioms.ttl's header calls out as the mistake to avoid.

    Sensor/Signal/Component particulars are minted here, scoped to the device
    that owns them (sensor_iri/signal_iri/component_iri) — never a shared
    type-level IRI. The scaffold catalogue is consulted only to check the
    archetype's sensor/signal/component concept is a legitimate individuated
    type before minting. Their per-alarm CONDITION (hasSensorOperationState,
    hasComponentOperationState, hasDeviceOperationState, ...) is not asserted
    here — that is situational, not background, and belongs to
    condition_for_event; see leaf_properties/ground_leaf_properties.

    `sensor_identity`/`component_identity` are the {(device_id, concept):
    refinements} maps from resolve_particular_identities, computed ONCE by
    the caller over the device's/patient's full event history (never
    re-derived here from `events`, which — via Timeline.background_at — may
    be only the subset revealing at one tick; the merge decision must not
    depend on that). Both default to empty so a caller with no cross-event
    history to resolve (e.g. a single-event test) can omit them.
    """
    sensor_identity = sensor_identity or {}
    component_identity = component_identity or {}
    g = Graph()
    sensor_refiners = refining_properties(kb, MDA.Sensor)
    component_refiners = refining_properties(kb, MDA.Component)
    for ev in events:
        type_iri = kb.type_index.get(ev.label)
        if type_iri is None:
            continue
        arch = archetype_structure(kb, type_iri)
        patient, dev = patient_iri(ev.patient), device_iri(ev.device_id)
        sensor_concept = arch.concept(MDA.Sensor)
        signal_concept = arch.concept(MDA.Signal)
        component_concept = arch.concept(MDA.Component)
        own_sensor_refinements = {p: v for p in sensor_refiners
                                  if (v := arch.value(MDA.Sensor, p)) is not None}
        sensor_refinements = sensor_identity.get((ev.device_id, sensor_concept),
                                                  own_sensor_refinements)
        own_component_refinements = {p: v for p in component_refiners
                                     if (v := arch.value(MDA.Component, p)) is not None}
        component_refinements = component_identity.get((ev.device_id, component_concept),
                                                         own_component_refinements)
        sen = (sensor_iri(ev.device_id, sensor_concept, sensor_refinements)
               if sensor_concept is not None and sensor_concept in kb.scaffold_concepts
               else None)
        sig = (signal_iri(ev.device_id, sensor_concept, signal_concept, sensor_refinements)
               if (sen is not None and signal_concept is not None
                   and signal_concept in kb.scaffold_concepts)
               else None)
        comp = (component_iri(ev.device_id, component_concept, component_refinements)
                if component_concept is not None and component_concept in kb.scaffold_concepts
                else None)

        device_type = arch.concept(MDA.Device)

        g.add((patient, RDF.type, MDA.Patient))
        g.add((patient, DCTERMS.identifier, Literal(ev.patient)))
        if device_type:
            g.add((dev, RDF.type, device_type))
            g.add((dev, DCTERMS.identifier, Literal(ev.device_id)))
        if sen is not None:
            g.add((sen, RDF.type, sensor_concept))
            g.add((dev, MDA.hasSensor, sen))
            for prop, value in sensor_refinements.items():
                g.add((sen, prop, value))
            if sig is not None:
                g.add((sig, RDF.type, signal_concept))
                g.add((sen, MDA.producesSignal, sig))
        if comp is not None:
            g.add((comp, RDF.type, component_concept))
            g.add((dev, MDA.hasComponent, comp))
            for prop, value in component_refinements.items():
                g.add((comp, prop, value))
    return g


def alarm_message(kb: KB, ev: Event) -> Graph:
    """
    The alarm and its per-alarm message node.  hasMessage points to a distinct
    mda:AlarmMessage (not the patient); the message concernsPatient the shared,
    persistent patient — the merge anchor.
    """
    g = Graph()
    type_iri = kb.type_index.get(ev.label)
    if type_iri is None:
        return g
    arch = archetype_structure(kb, type_iri)
    a = alarm_iri(ev.device_id, ev.start)
    msg = message_iri(ev.device_id, ev.start)
    patient = patient_iri(ev.patient)

    g.add((a, RDF.type, MDA.Alarm))
    g.add((a, MDA.isOfType, type_iri))
    g.add((a, MDA.hasLabel, Literal(ev.label, lang="en")))
    g.add((a, MDA.hasStart, Literal(ev.start.isoformat(), datatype=XSD.dateTime)))
    g.add((a, MDA.hasEnd, Literal(ev.end.isoformat(), datatype=XSD.dateTime)))
    ground_leaf_properties(g, kb, arch, MDA.Alarm, a)
    g.add((a, MDA.hasMessage, msg))
    g.add((msg, RDF.type, MDA.AlarmMessage))
    g.add((msg, MDA.concernsPatient, patient))
    return g


def alarm_condition(kb: KB, ev: Event, sensor_identity: dict = None,
                     component_identity: dict = None) -> Graph:
    """
    The alarm's situational content, asserted onto the shared merge anchors so
    that concurrent alarms accumulate into one coherent picture: the clinical
    condition (metric identity + rate/rhythm), the operation state of
    whichever node the archetype reaches (sensor, component, device), and the
    signal's quality state.  Conflicting values are resolved last-wins at
    merge time (see merge_conditions).
    """
    return condition_for_event(kb, ev.label, ev.device_id, sensor_identity, component_identity)


def condition_for_event(kb: KB, label: str, device_id: str, sensor_identity: dict = None,
                         component_identity: dict = None) -> Graph:
    """
    The condition an alarm of this kind, on this device, contributes.

    It depends only on the archetype and the device it is grounded to, never on
    the occurrence: the nodes it attaches to are that device's sensor/signal/
    component particulars (sensor_iri/signal_iri/component_iri — never a
    shared, type-level anchor), and the values come from the blueprint. That is
    what lets a timeline compute one condition per distinct (label, device)
    pair instead of one per alarm, while keeping two devices of the same type
    — or the same device across two patients — from colliding onto one node.

    Every node the archetype reaches is grounded the same, generic way
    (ground_leaf_properties, driven by leaf_properties): whatever
    condition-carrying property the ontology declares on that class is read
    off the archetype and asserted, with no per-property code here. Adding a
    new condition column to the ontology (on Metric, Signal, Sensor,
    Component or Device) therefore needs no change in this function.

    `sensor_identity`/`component_identity` are the same resolved {(device_id,
    concept): refinements} maps background_graph takes (see
    resolve_particular_identities) — a (label, device) pair must resolve to
    the very same sensor/signal/component IRIs background_graph minted for
    it, or the two would talk past each other.
    """
    sensor_identity = sensor_identity or {}
    component_identity = component_identity or {}
    g = Graph()
    type_iri = kb.type_index.get(label)
    if type_iri is None:
        return g
    arch = archetype_structure(kb, type_iri)

    sensor_concept = arch.concept(MDA.Sensor)
    signal_concept = arch.concept(MDA.Signal)
    own_sensor_refinements = {p: v for p in refining_properties(kb, MDA.Sensor)
                              if (v := arch.value(MDA.Sensor, p)) is not None}
    sensor_refinements = sensor_identity.get((device_id, sensor_concept), own_sensor_refinements)
    sen = (sensor_iri(device_id, sensor_concept, sensor_refinements)
           if sensor_concept in kb.scaffold_concepts else None)
    sig = (signal_iri(device_id, sensor_concept, signal_concept, sensor_refinements)
           if sen is not None and signal_concept in kb.scaffold_concepts else None)

    component_concept = arch.concept(MDA.Component)
    own_component_refinements = {p: v for p in refining_properties(kb, MDA.Component)
                                 if (v := arch.value(MDA.Component, p)) is not None}
    component_refinements = component_identity.get((device_id, component_concept),
                                                     own_component_refinements)
    comp = (component_iri(device_id, component_concept, component_refinements)
            if component_concept in kb.scaffold_concepts else None)

    metric = arch.concept(MDA.Metric)
    if sen is not None and metric is not None:
        cond = INST[f"Metric_{_clean(device_id)}_{_refined_suffix(sensor_concept, sensor_refinements)}"
                    f"_{_local(metric)}"]
        g.add((sen, MDA.detectsMetric, cond))
        g.add((cond, RDF.type, metric))
        ground_leaf_properties(g, kb, arch, MDA.Metric, cond)

    ground_leaf_properties(g, kb, arch, MDA.Sensor, sen)
    ground_leaf_properties(g, kb, arch, MDA.Signal, sig)
    ground_leaf_properties(g, kb, arch, MDA.Component, comp)
    ground_leaf_properties(g, kb, arch, MDA.Device, device_iri(device_id))
    return g


def merge_conditions(graphs: list, last_wins: set) -> Graph:
    """
    Merge condition graphs given in ascending start order.  Non-functional
    facts union; for `last_wins` properties (see KB.last_wins/
    condition_properties) the latest alarm's value replaces any earlier one
    on the same subject — each describes a single current condition (e.g.
    Impaired → CriticallyImpaired), not an accumulating fact.
    """
    g = Graph()
    for src in graphs:
        for s, p, o in src:
            if p in last_wins:
                g.remove((s, p, None))
            g.add((s, p, o))
    return g


# ── INFERENCE ─────────────────────────────────────────────────────────────────

@dataclass
class Timeline:
    """
    One patient's monitoring window, with the situational graph computable at
    any instant.

    The per-event graphs are built once and reused across ticks, so stepping
    through time is cheap enough to drive a UI.  Both the TriG writer
    (op_inference.py) and the visual (op_visual.py) go through this, so the two
    cannot disagree about what the situation at a given instant is.
    """
    patient: str
    events: list
    background: Graph
    ticks: list
    window: timedelta
    _kb: KB
    _messages: dict          # id(event) → alarm + message node (unique per event)
    _conditions: dict        # (label, device_id) → condition graph
    _persisted: dict         # (label, device_id) → post-alarm operation state
    _cache: dict             # active (label, device) sequence → merged + entailed
    _bg_cache: dict          # active (label, device) set → revealed anchors
    _sensor_identity: dict   # (device_id, concept) → resolved refinements (resolve_particular_identities)
    _component_identity: dict  # same, for MDA.Component

    def active_at(self, t: datetime) -> list:
        """Alarms valid at `t`, in ascending start order (so last wins)."""
        return sorted((e for e in self.events if e.start <= t <= e.end),
                      key=lambda e: e.start)

    def revealing_at(self, t: datetime) -> list:
        """
        Alarms whose knowledge is valid at `t`, and so reveals structural
        context: the active ones, plus any in their post-alarm window that
        actually leave *persisting operation state* behind.

        The second clause is deliberately narrower than "any alarm still in its
        window".  Per the temporal model only operation state survives past an
        alarm's end — a plain physiological alarm's situational facts expire at
        `end` and leave nothing — so once ended it should stop revealing its
        sensor.  A technical alarm whose inferred `Enabled` lingers keeps its
        device/sensor/signal on screen for exactly as long as that state holds,
        which is what stops the persisting state from floating unattached.
        """
        def valid(e):
            if e.start <= t <= e.end:
                return True
            return (e.end < t < e.end + self.window
                    and len(self._persisted[(e.label, e.device_id)]) > 0)
        return sorted((e for e in self.events if valid(e)),
                      key=lambda e: e.start)

    def background_at(self, t: datetime) -> Graph:
        """
        The merge anchors revealed by the alarms valid at `t` — the patient,
        the devices those alarms came from, and only the sensors and signals
        those alarms actually implicate.  Includes alarms in their post-alarm
        window, so the operation state persisting after an alarm ends stays
        attached to the patient and device it belongs to rather than floating.

        `self.background` is the accumulation over the patient's whole stream,
        which is what the TriG default graph holds.  That is knowledge about the
        deployment, not about this instant: at a tick where only an SpO2 alarm is
        firing it would still show the ECG and arterial-line sensors, which no
        active alarm has told us anything about.  A view of the situation asks
        for this instead.
        """
        revealing = self.revealing_at(t)
        key = tuple(sorted((e.label, e.device_id) for e in revealing))
        if key not in self._bg_cache:
            self._bg_cache[key] = background_graph(
                self._kb, revealing, self._sensor_identity, self._component_identity)
        return self._bg_cache[key]

    def situation_at(self, t: datetime, mode: str = "situational") -> Graph:
        """
        The situational awareness at `t` — the tick's named-graph content.

        `mode` selects how much of the reasoner's output is folded in:
        "situational" (default, unchanged behaviour) keeps only
        mda:situational-tagged predicates — exactly what op_inference.py
        writes to kg_inference.trig. "all" keeps everything the reasoner
        actually entailed reachable from this tick's own nodes, including
        background/taxonomic facts (e.g. an entailed rdf:type superclass
        membership) that mda:situational deliberately excludes from the
        export. op_inference.py never passes mode — its output is
        unaffected by this parameter's existence. op_visual.py uses both, so
        a viewer can toggle between them without kg_inference.trig changing
        at all.

        Reasons over background_at(t) — the devices/sensors/signals THIS
        tick's alarms actually reveal — not self.background, which is the
        accumulation over the patient's whole stream. mda:administers and
        mda:approximates are entailed purely from a node's TYPE, so a device
        or metric needs no active alarm to produce them; reasoning over the
        full background would extract them for every device the patient has
        ever had an alarm on, not just the one implicated right now — a
        ventilator alarm's snapshot would carry an unrelated ECMO circuit's
        therapeutic modality. That is what background_at(t) exists to
        prevent for the drawn anchors; it needs to bound the reasoning input
        too, not just what op_visual.py draws on top of it.

        Everything below the per-alarm message depends only on *which* archetypes
        are active and in what order, not on which particular alarms they are, so
        the reasoned part is cached against that sequence.  Two bursts of the same
        alarms therefore cost one closure, not two — for both modes at once,
        since entailed_situation computes them from a single reasoning pass.
        Caching by `active` alone (not the broader `revealing`, which
        background_at(t) is keyed on) stays correct here: which OTHER,
        lingering devices happen to also be revealing at a given instant
        never changes what a type-derived fact entails for the actively
        alarming device itself.
        """
        g = Graph()
        active = self.active_at(t)
        patient = patient_iri(self.patient)
        for e in active:
            g += self._messages[id(e)]              # unique per alarm occurrence
            # isMonitoredBy is asserted here, not in background: it is true only
            # while this alarm is active, never a standing fact — see
            # background_graph's docstring for why.
            g.add((patient, MDA.isMonitoredBy, device_iri(e.device_id)))

        key = tuple((e.label, e.device_id) for e in active)
        if key not in self._cache:
            merged = merge_conditions([self._conditions[(e.label, e.device_id)]
                                        for e in active], self._kb.last_wins)
            situational, everything = Graph(), Graph()
            situational += merged
            everything += merged
            if active:
                states, clinical, all_entailed = entailed_situation(
                    self._kb, self.background_at(t) + merged)
                situational += states
                situational += clinical
                everything += states
                everything += all_entailed
            self._cache[key] = (situational, everything)
        g += self._cache[key][0 if mode == "situational" else 1]

        for e in self.events:                       # post-alarm persistence
            if e.end < t < e.end + self.window:
                g += self._persisted[(e.label, e.device_id)]
        return g

    def state_label(self, t: datetime, situation: Graph) -> str:
        """Short human label for a tick: the active alarms, or why it is empty."""
        active = self.active_at(t)
        if active:
            return ", ".join(e.label.split(" - ")[-1] for e in active)
        return "post-alarm" if len(situation) else "idle"


def ticks_for(events: list, window: timedelta) -> list:
    """State-change instants: each start, each end, the mid-window point
    (to witness post-alarm persistence), and the window expiry."""
    times = set()
    for e in events:
        times.add(e.start)
        times.add(e.end)
        times.add(e.end + window / 2)
        times.add(e.end + window)
    return sorted(times)


def _report_identity_conflicts(patient: str, cls: URIRef, conflicts: list) -> None:
    if not conflicts:
        return
    print(f"[WARN]  {patient}: {len(conflicts)} {_local(cls).lower()} identity conflict(s) — "
          f"kept as separate particulars, never merged:")
    for device_id, concept, prop, values in conflicts:
        vals = ", ".join(sorted(_local(v) for v in values))
        print(f"        {device_id} / {_local(concept)}: {_local(prop)} disagrees ({vals})")


def build_timeline(kb: KB, patient: str, events: list) -> Timeline:
    """
    Precompute everything a patient's timeline needs to answer any instant.

    Conditions and their entailed operation state are keyed by (label,
    device_id), not by event: two occurrences of the same alarm on the same
    device produce the same condition graph, so the reasoner runs once per
    distinct (archetype, device) pair rather than once per alarm — and two
    devices of the same type (or the same alarm on a different device) never
    share a condition, because they never share a sensor/signal/component
    particular.

    Sensor and component identity are each resolved ONCE here, from this
    patient's full event history (see resolve_particular_identities), before
    anything is minted — background_graph and condition_for_event both
    consult the same resolved maps, so a (label, device) pair's condition
    always lands on the same sensor/signal/component IRIs background_graph
    minted for it, regardless of which subset of events a given call happens
    to see (Timeline.background_at calls background_graph with only the
    alarms revealing at one tick).
    """
    sensor_identity, sensor_conflicts = resolve_particular_identities(kb, MDA.Sensor, events)
    _report_identity_conflicts(patient, MDA.Sensor, sensor_conflicts)
    component_identity, component_conflicts = resolve_particular_identities(kb, MDA.Component, events)
    _report_identity_conflicts(patient, MDA.Component, component_conflicts)

    background = background_graph(kb, events, sensor_identity, component_identity)
    keys = sorted({(e.label, e.device_id) for e in events})
    conditions = {k: condition_for_event(kb, *k, sensor_identity, component_identity) for k in keys}
    return Timeline(
        patient=patient,
        events=events,
        background=background,
        ticks=ticks_for(events, kb.window),
        window=kb.window,
        _kb=kb,
        _messages={id(e): alarm_message(kb, e) for e in events},
        _conditions=conditions,
        _persisted={k: inferred_states(kb, background + conditions[k])
                    for k in keys},
        _cache={},
        _bg_cache={},
        _sensor_identity=sensor_identity,
        _component_identity=component_identity,
    )


def reason(base: Graph, static: Graph) -> Graph:
    """Materialise the OWL-RL closure of `static + base` (real reasoner)."""
    g = Graph()
    g += static
    g += base
    owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(g)
    return g


def clinical_predicates(kb: KB) -> set:
    """
    The relations whose entailed assertions belong in a per-alarm situational
    export — read directly off the ontology's mda:situational true tag
    (see ontology.ttl's "Situational-reasoning classification" section),
    not derived from graph shape.

    Earlier versions of this function tried to derive the set structurally —
    first from kb.tree (a single spanning tree, one parent per class, built
    for CSV/instance attachment) via properties_below, then from a
    multi-parent reachability walk (properties_reachable) rooted at
    mda:Metric. Both worked only by accident of which classes happen to be
    reachable from Metric; neither had a principled way to also include
    mda:administers/targetsProcess (rooted at mda:Device, a sibling branch,
    not a descendant of Metric) without conflating "reachable from Metric"
    with "belongs in the export" — two different questions that happened to
    have overlapping answers only for the property chain, not the
    therapeutic one. Tagging predicates directly answers the actual question
    instead of a proxy for it.
    """
    return {p for p in kb.reasoning_static.subjects(MDA.situational, Literal(True))}


def clinical_context(kb: KB, abox: Graph) -> Graph:
    """
    The situational context entailed by an ABox: metric → physiological
    property → process → organ → organ system, AND device → therapeutic
    modality → process (mda:situational predicates — see clinical_predicates),
    walked out from the nodes the situation actually mentions so the snapshot
    carries the reachable chain and not the whole knowledge base. Named for
    its original, narrower scope (the physiological chain); it now also
    carries therapeutic content since mda:administers/targetsProcess were
    tagged mda:situational too.

    Unlike operation state these facts do NOT persist past alarm-end.  They hang
    off the alarm's metric/device node, which is itself only valid while the
    alarm is active; the anatomy and device capability are timeless but this
    alarm's implication of them is not.
    """
    return _extract_clinical(kb, reason(abox, kb.reasoning_static), abox)


def _extract_clinical(kb: KB, reasoned: Graph, abox: Graph) -> Graph:
    """The mda:situational-tagged part of an already-computed closure."""
    predicates = clinical_predicates(kb)
    g = Graph()
    frontier = {t for triple in abox for t in (triple[0], triple[2])
                if isinstance(t, URIRef)}
    seen = set()
    while frontier:
        nxt = set()
        for node in frontier - seen:
            seen.add(node)
            for p, o in reasoned.predicate_objects(node):
                if p not in predicates:
                    continue
                g.add((node, p, o))
                if isinstance(o, URIRef):
                    nxt.add(o)
        frontier = nxt
    return g


def _extract_all(kb: KB, reasoned: Graph, abox: Graph) -> Graph:
    """
    Everything the reasoner entailed via the domain's own object properties,
    reachable from this abox's own nodes — the same frontier walk as
    _extract_clinical, but the predicate whitelist is "every owl:ObjectProperty
    the ontology declares" (clinical_predicates(kb) is a strict subset of
    this) instead of just the mda:situational-tagged ones, plus rdf:type so an
    entailed superclass membership is visible. Not exported anywhere
    (kg_inference.trig only ever carries the situational/state subsets); this
    exists for op_visual.py's "all entailed" view.

    Deliberately narrower than "every triple in the closure": SKOS/RDFS/OWL
    bookkeeping (skos:broader, rdfs:subClassOf, skos:inScheme, owl:sameAs,
    dcterms:identifier, ...) is excluded, and rdf:type's object is never
    added back to the frontier. Without both, touching a single vocabulary
    concept pulls in that concept's entire scheme (broader chains, siblings,
    scheme metadata) — background/taxonomic noise even by "show me
    everything" standards, not situational content about this alarm. An
    earlier version of this function filtered nothing and pulled in ~50x the
    triples for a single tick, almost none of them meaningful.
    """
    object_properties = set(kb.reasoning_static.subjects(RDF.type, OWL.ObjectProperty))
    g = Graph()
    frontier = {t for triple in abox for t in (triple[0], triple[2])
                if isinstance(t, URIRef)}
    seen = set()
    while frontier:
        nxt = set()
        for node in frontier - seen:
            seen.add(node)
            for p, o in reasoned.predicate_objects(node):
                if p == RDF.type:
                    if isinstance(o, URIRef):
                        g.add((node, p, o))          # shown, but not a doorway
                    continue
                if p not in object_properties:
                    continue
                g.add((node, p, o))
                if isinstance(o, URIRef):
                    nxt.add(o)
        frontier = nxt
    return g


def inferred_states(kb: KB, abox: Graph) -> Graph:
    """
    The operation-state facts entailed by an ABox (background + situation):
    signal quality ⇒ signal/sensor/device Enabled, via the property chains.
    Only the entailed hasOperationState triples are returned (not the closure).
    These persist past alarm-end for the PostAlarmValidScheme window.
    """
    return _extract_states(reason(abox, kb.reasoning_static))


def _extract_states(reasoned: Graph) -> Graph:
    """The operation-state part of an already-computed closure."""
    g = Graph()
    for s, o in reasoned.subject_objects(MDA.hasOperationState):
        if str(s).startswith(str(ENTITY)) or str(s).startswith(str(INST)):
            g.add((s, MDA.hasOperationState, o))
    return g


def entailed_situation(kb: KB, abox: Graph):
    """
    Operation state, situational (mda:situational-tagged) context, and the
    full entailed closure, from a SINGLE reasoning pass.

    `inferred_states` and `clinical_context` each reason independently, which is
    fine for a one-off but doubles the cost per tick.  Stepping a timeline calls
    this instead: OWL-RL runs once and all three views are read off the same
    result. The third (full) view exists for op_visual.py; nothing writes it
    to kg_inference.trig.
    """
    reasoned = reason(abox, kb.reasoning_static)
    return (_extract_states(reasoned), _extract_clinical(kb, reasoned, abox),
            _extract_all(kb, reasoned, abox))
