# Competency Question validation report

Base graph: ontology.ttl, vocab.ttl, inference.ttl, kg.ttl — 3107 triples (7546 after OWL-RL closure, +4439 entailed).

## CQ1_shared_technical_dependencies

**Question:** Which alarm messages depend on the same technical components or measurements for their generation?

**Graph:** base (asserted only)

```sparql
# question: Which alarm messages depend on the same technical components or measurements for their generation?
#
# For every technical concept (device, sensor, component, signal, or metric
# type) reachable from an archetype's message blueprint, group the archetypes
# that reach it. A group with more than one archetype is two-or-more alarms
# generated off the same underlying technical dependency, at whatever
# granularity that dependency sits — a shared device model (e.g. every
# PHILIPSMONITOR alarm), a shared sensor (e.g. PulseOximeter), or a shared
# metric (e.g. Volume_Tidal).
#
# Runs against the ASSERTED graph only (no `reasoning: required` directive):
# this asks what kg.ttl actually states an archetype depends on, not what a
# reasoner can additionally derive (see cq_QA.py's module docstring — over
# the OWL-RL closure every archetype also gains entailed superclass types
# like mda:Device, which would flood this with meaningless broad matches).

PREFIX mda: <http://example.org/model-device-alarm-knowledge#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>

SELECT ?technicalConcept (GROUP_CONCAT(DISTINCT ?label; separator=" | ") AS ?alarms)
       (COUNT(DISTINCT ?a) AS ?matchCount) WHERE {
  ?a a mda:AlarmType ; mda:hasLabel ?label .
  ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent|mda:producesSignal|mda:detectsMetric)* ?node .
  ?node rdf:type ?technicalConcept .
  ?technicalConcept a skos:Concept .
}
GROUP BY ?technicalConcept
HAVING (COUNT(DISTINCT ?a) > 1)
ORDER BY DESC(?matchCount) ?technicalConcept
```

**Outcome:** 31 row(s)

| technicalConcept | alarms | matchCount |
|---|---|---|
| device:PhysiologicalMonitor_Philips | PHILIPSMONITOR - ABP verkleinen \| PHILIPSMONITOR - CO2 wijzig schaal l \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - Extreme Tachy \| PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. \| PHILIPSMONITOR - Niet te leren ECG \| PHILIPSMONITOR - Resp elektr.los \| PHILIPSMONITOR - SpO2 geen pols \| PHILIPSMONITOR - SpO2 hoog \| PHILIPSMONITOR - SpO2 laag \| PHILIPSMONITOR - SpO2 lage PFI \| PHILIPSMONITOR - Storing in SpO2 | 13 |
| sensor:PneumoTachograph | DATEXOHMEDACOMVENTILATOR - MVexp High \| DATEXOHMEDACOMVENTILATOR - RR High \| DATEXOHMEDACOMVENTILATOR - VTexp High \| HULBUS - Vte high \| MEDIBUS - Slagvolume hoog \| SERVOI - Ademfrequentie: Hoog \| SERVOI - Exp. Minuutvolume \| SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag \| SERVOU - Exp. minuutvol. laag | 12 |
| signal:AirwayFlow_waveform | DATEXOHMEDACOMVENTILATOR - MVexp High \| DATEXOHMEDACOMVENTILATOR - RR High \| DATEXOHMEDACOMVENTILATOR - VTexp High \| HULBUS - Vte high \| MEDIBUS - Slagvolume hoog \| SERVOI - Ademfrequentie: Hoog \| SERVOI - Exp. Minuutvolume \| SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag \| SERVOU - Exp. minuutvol. laag | 12 |
| device:Incubator_Draeger | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low \| MEDIBUS - Check patient \| MEDIBUS - Humidity low \| MEDIBUS - Humidity Sensor inoperable \| MEDIBUS - Mattress temperature  setting deviation \| MEDIBUS - Radiant heater after 15 mins. operation \| MEDIBUS - Verbinding verbroken | 8 |
| device:MechanicalVentilator_ServoU_Getinge | SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag \| SERVOU - Beademingsdruk hoog \| SERVOU - Exp. minuutvol. laag \| SERVOU - PEEP laag \| SERVOU - Volume uit blokkade | 8 |
| sensor:PulseOximeter | Monitor - Lage SpO2 \| Monitor - SpO2 sensor uit \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - SpO2 geen pols \| PHILIPSMONITOR - SpO2 hoog \| PHILIPSMONITOR - SpO2 laag \| PHILIPSMONITOR - SpO2 lage PFI \| PHILIPSMONITOR - Storing in SpO2 | 8 |
| sensor:Pressure_transducer | CARDIOHELP - pVen onder waarschuwingsgrens \| Monitor - ART statische druk \| Monitor - Hoge ARTmean \| Monitor - Lage ARTmean \| PHILIPSMONITOR - ABP verkleinen \| SERVOU - Beademingsdruk hoog \| SERVOU - PEEP laag | 7 |
| signal:PPG_waveform | Monitor - Lage SpO2 \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - SpO2 geen pols \| PHILIPSMONITOR - SpO2 hoog \| PHILIPSMONITOR - SpO2 laag \| PHILIPSMONITOR - SpO2 lage PFI \| PHILIPSMONITOR - Storing in SpO2 | 7 |
| component:ConnectionUnit | CARDIOHELP - Verbinding verbroken \| CRITICOOL - Verbinding verbroken \| EDWARDS - Verbinding verbroken \| MEDIBUS - Verbinding verbroken \| SERVOI - Verbinding verbroken | 6 |
| device:MechanicalVentilator_Datexohmedacom_GEHealthcare | DATEXOHMEDACOMVENTILATOR - MVexp High \| DATEXOHMEDACOMVENTILATOR - Patient Disconnected \| DATEXOHMEDACOMVENTILATOR - Plimit Reached \| DATEXOHMEDACOMVENTILATOR - RR High \| DATEXOHMEDACOMVENTILATOR - VTexp High | 5 |
| device:PhysiologicalMonitor_Infinity_Draeger | Monitor - ART statische druk \| Monitor - Hoge ARTmean \| Monitor - Lage ARTmean \| Monitor - Lage SpO2 \| Monitor - SpO2 sensor uit | 5 |
| metric:RespiratoryRate | DATEXOHMEDACOMVENTILATOR - RR High \| SERVOI - Ademfrequentie: Hoog \| SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag | 5 |
| metric:SpO2 | Monitor - Lage SpO2 \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - SpO2 hoog \| PHILIPSMONITOR - SpO2 laag | 4 |
| metric:Volume_Minute | DATEXOHMEDACOMVENTILATOR - MVexp High \| SERVOI - Exp. Minuutvolume \| SERVOU - Exp. minuutvol. laag | 4 |
| sensor:ElectroCardioGraphy_sensor | PHILIPSMONITOR - Extreme Tachy \| PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. \| PHILIPSMONITOR - Niet te leren ECG | 4 |
| signal:ABP_waveform | Monitor - ART statische druk \| Monitor - Hoge ARTmean \| Monitor - Lage ARTmean \| PHILIPSMONITOR - ABP verkleinen | 4 |
| signal:ECG_signal | PHILIPSMONITOR - Extreme Tachy \| PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. \| PHILIPSMONITOR - Niet te leren ECG | 4 |
| device:MechanicalVentilator_Draeger | MEDIBUS - Slagvolume hoog \| MEDIBUS - Verbinding verbroken \| MEDIBUS - Volume niet constant | 3 |
| device:MechanicalVentilator_Hulbus_LowensteinMedical | HULBUS - 345 \| HULBUS - Leak too high \| HULBUS - Vte high | 3 |
| device:MechanicalVentilator_ServoI_Getinge | SERVOI - Ademfrequentie: Hoog \| SERVOI - Exp. Minuutvolume \| SERVOI - Verbinding verbroken | 3 |
| metric:HeartRate | PHILIPSMONITOR - Extreme Tachy \| PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. | 3 |
| metric:Volume_Tidal | DATEXOHMEDACOMVENTILATOR - VTexp High \| HULBUS - Vte high \| MEDIBUS - Slagvolume hoog | 3 |
| signal:AirwayPressure_waveform | DATEXOHMEDACOMVENTILATOR - Plimit Reached \| SERVOU - Beademingsdruk hoog \| SERVOU - PEEP laag | 3 |
| device:ExtracorporealMembraneOxygenator_CardioHelp_Getinge | CARDIOHELP - pVen onder waarschuwingsgrens \| CARDIOHELP - Verbinding verbroken | 2 |
| device:MechanicalVentilator_Trilogy_Philips | TRILOGY - 0x79 \| TRILOGY - Netspanning afwezig | 2 |
| metric:ABP_Mean | Monitor - Hoge ARTmean \| Monitor - Lage ARTmean | 2 |
| metric:AirTemperature | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low | 2 |
| metric:AirwayPressure | DATEXOHMEDACOMVENTILATOR - Plimit Reached \| SERVOU - Beademingsdruk hoog | 2 |
| sensor:HumiditySensor | MEDIBUS - Humidity low \| MEDIBUS - Humidity Sensor inoperable | 2 |
| sensor:Temperature_sensor | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low | 2 |
| signal:Temp_signal | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low | 2 |

## CQ2_shared_physiological_knowledge

**Question:** Which alarm messages convey knowledge concerning the same physiological process or physiological property?

**Graph:** reasoned (OWL-RL closure)

```sparql
# question: Which alarm messages convey knowledge concerning the same physiological process or physiological property?
#
# Unlike CQ1 (the technical layer, directly asserted), this is a CLINICAL
# question: it asks what an alarm's metric implies about physiology, which
# is never asserted directly on an archetype — kg.ttl only ever types a
# metric node `a metric:SpO2` or similar. The link from that metric TYPE to
# a physiologicalProperty (mda:approximates) is a class-level bridge
# restriction in inference.ttl, and only fires on an actual metric instance
# under OWL-RL (rule cls-hv1). property->process (mda:isPropertyOf) is a
# plain asserted triple once the bridge is crossed (inference.ttl's "TAIL
# axioms" — see its header). So this CQ puts the reasoner itself under test,
# the same way CQ-set E does in ../../CQ_VALIDATION_PLAN.md.
#
# reasoning: required
#
# Two levels of grouping, both reported: ?level="property" groups alarms
# reaching the exact same physiologicalProperty (e.g. two SpO2-derived
# alarms both -> SaO2); ?level="process" groups alarms reaching the same
# physiologicalProcess even via DIFFERENT properties (e.g. an arterial-
# pressure alarm and a venous-pressure alarm both -> VascularCompliance) —
# the coarser convergence CQ3 shows exists at the vocabulary level.

PREFIX mda: <http://example.org/model-device-alarm-knowledge#>

SELECT ?level ?concept (GROUP_CONCAT(DISTINCT ?label; separator=" | ") AS ?alarms)
       (COUNT(DISTINCT ?a) AS ?matchCount) WHERE {
  ?a a mda:AlarmType ; mda:hasLabel ?label .
  ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent)*/mda:detectsMetric ?metric .
  {
    ?metric mda:approximates ?concept .
    BIND("property" AS ?level)
  } UNION {
    ?metric mda:approximates/mda:isPropertyOf ?concept .
    BIND("process" AS ?level)
  }
}
GROUP BY ?level ?concept
HAVING (COUNT(DISTINCT ?a) > 1)
ORDER BY ?level DESC(?matchCount)
```

**Outcome:** 12 row(s)

| level | concept | alarms | matchCount |
|---|---|---|---|
| process | physiologicalProcess:PulmonaryVentilation | HULBUS - Vte high \| SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag \| DATEXOHMEDACOMVENTILATOR - Plimit Reached \| DATEXOHMEDACOMVENTILATOR - VTexp High \| MEDIBUS - Slagvolume hoog \| SERVOI - Ademfrequentie: Hoog \| DATEXOHMEDACOMVENTILATOR - RR High \| SERVOU - PEEP laag \| SERVOI - Exp. Minuutvolume \| DATEXOHMEDACOMVENTILATOR - MVexp High \| SERVOU - Exp. minuutvol. laag \| SERVOU - Beademingsdruk hoog | 15 |
| process | physiologicalProcess:VascularCompliance | Monitor - Lage ARTmean \| PHILIPSMONITOR - ABP verkleinen \| PHILIPSMONITOR - SpO2 lage PFI \| CARDIOHELP - pVen onder waarschuwingsgrens \| Monitor - Hoge ARTmean | 5 |
| process | physiologicalProcess:PulmonaryOxygenation | PHILIPSMONITOR - SpO2 laag \| Monitor - Lage SpO2 \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - SpO2 hoog | 4 |
| process | physiologicalProcess:CardiacContraction | PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. \| PHILIPSMONITOR - Extreme Tachy | 3 |
| process | physiologicalProcess:ThermoRegulation | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low | 2 |
| property | physiologicalProperty:RespirationVolume | HULBUS - Vte high \| DATEXOHMEDACOMVENTILATOR - VTexp High \| MEDIBUS - Slagvolume hoog \| SERVOI - Exp. Minuutvolume \| DATEXOHMEDACOMVENTILATOR - MVexp High \| SERVOU - Exp. minuutvol. laag | 7 |
| property | physiologicalProperty:RespirationRate | SERVOU - Ademfrequentie hoog \| SERVOU - Ademfrequentie laag \| SERVOI - Ademfrequentie: Hoog \| DATEXOHMEDACOMVENTILATOR - RR High | 5 |
| property | physiologicalProperty:SaO2 | PHILIPSMONITOR - SpO2 laag \| Monitor - Lage SpO2 \| PHILIPSMONITOR - Desaturatie \| PHILIPSMONITOR - SpO2 hoog | 4 |
| property | physiologicalProperty:RespirationPressure | DATEXOHMEDACOMVENTILATOR - Plimit Reached \| SERVOU - PEEP laag \| SERVOU - Beademingsdruk hoog | 3 |
| property | physiologicalProperty:ElectricalHeartRate | PHILIPSMONITOR - HF hoog \| PHILIPSMONITOR - Lage hartfreq. \| PHILIPSMONITOR - Extreme Tachy | 3 |
| property | physiologicalProperty:ArterialPressure | Monitor - Lage ARTmean \| PHILIPSMONITOR - ABP verkleinen \| Monitor - Hoge ARTmean | 3 |
| property | physiologicalProperty:Temperature | MEDIBUS - Air temperature high \| MEDIBUS - Air temperature low | 2 |

## CQ3_convergent_measurements

**Question:** Which different technical measurements can provide information about the same physiological process or property?

**Graph:** base (asserted only)

```sparql
# question: Which different technical measurements can provide information about the same physiological process or property?
#
# The inverse of CQ2: not which ALARMS converge, but which METRIC TYPES do —
# a vocabulary-level question about inference.ttl's bridge+tail axioms
# themselves, independent of which archetypes in kg.ttl happen to use them.
# A metric TYPE -> physiologicalProperty link is a class-level restriction
# (`?metricType rdfs:subClassOf [ owl:onProperty mda:approximates ;
# owl:hasValue ?property ]`) asserted directly in inference.ttl — reading it
# is just matching that triple shape, no instance and no reasoner needed
# (contrast CQ2/CQ4, which ask about actual alarms and so need an instance
# for the restriction to fire on). property->process (mda:isPropertyOf) is
# likewise a plain asserted triple. Runs against the ASSERTED graph only.
#
# Two levels again: ?level="property" is direct convergence (e.g. ABP and
# ABP_Mean both approximate ArterialPressure); ?level="process" is the
# broader convergence once every property's own process is followed too
# (e.g. Volume_Tidal, Volume_Minute, RespiratoryRate, AirwayPressure and
# AirwayPressure_EndExpiratory — five distinct metrics — all inform
# PulmonaryVentilation).

PREFIX mda: <http://example.org/model-device-alarm-knowledge#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>

SELECT ?level ?target (GROUP_CONCAT(DISTINCT ?metricName; separator=" | ") AS ?measurements)
       (COUNT(DISTINCT ?metricConcept) AS ?matchCount) WHERE {
  {
    ?metricConcept rdfs:subClassOf [ a owl:Restriction ; owl:onProperty mda:approximates ; owl:hasValue ?target ] .
    BIND("property" AS ?level)
  } UNION {
    ?metricConcept rdfs:subClassOf [ a owl:Restriction ; owl:onProperty mda:approximates ; owl:hasValue ?property ] .
    ?property mda:isPropertyOf ?target .
    BIND("process" AS ?level)
  }
  BIND(REPLACE(STR(?metricConcept), "^.*/", "") AS ?metricName)
}
GROUP BY ?level ?target
HAVING (COUNT(DISTINCT ?metricConcept) > 1)
ORDER BY ?level DESC(?matchCount)
```

**Outcome:** 5 row(s)

| level | target | measurements | matchCount |
|---|---|---|---|
| process | physiologicalProcess:PulmonaryVentilation | RespiratoryRate \| Volume_Minute \| Volume_Tidal \| AirwayPressure \| AirwayPressure_EndExpiratory | 5 |
| process | physiologicalProcess:VascularCompliance | ABP \| ABP_Mean \| VenousPressure \| PulseFlowIndex | 4 |
| property | physiologicalProperty:ArterialPressure | ABP \| ABP_Mean | 2 |
| property | physiologicalProperty:RespirationVolume | Volume_Minute \| Volume_Tidal | 2 |
| property | physiologicalProperty:RespirationPressure | AirwayPressure \| AirwayPressure_EndExpiratory | 2 |

## CQ4_pathways_to_target

**Question:** Given a specific physiological property or process, which alarm messages can convey knowledge about it, and through which technical measurement pathways?

**Graph:** reasoned (OWL-RL closure)

```sparql
# question: Given a specific physiological property or process, which alarm messages can convey knowledge about it, and through which technical measurement pathways?
#
# Parametrised by ?target, bound below via VALUES to one example concept —
# swap it for any physiologicalProperty or physiologicalProcess IRI to ask
# the same question about a different target. The `(mda:isPropertyOf)?`
# zero-or-one path lets one query accept EITHER kind of target: zero hops
# when ?target is already the property an alarm's metric approximates, one
# hop when ?target is the coarser process a property belongs to.
#
# Same reasoner dependency as CQ2 (mda:approximates is entailed, not
# asserted — see that file's header) plus the same false-superclass hazard
# CQ1 avoids on the technical side: under the OWL-RL closure a metric
# instance also gains entailed types like mda:Metric and owl:Thing (and
# owlrl's internal restriction blank nodes), so ?metricConcept is
# constrained to an actual skos:Concept to keep the reported pathway to the
# specific metric TYPE, not that noise.
#
# reasoning: required
#
# Example below: physiologicalProcess:VascularCompliance — expect three
# alarms, through three distinct metric pathways (ABP/ABP_Mean -> ArterialPressure,
# VenousPressure -> VenousPressure, PulseFlowIndex -> TissuePerfusion).

PREFIX mda: <http://example.org/model-device-alarm-knowledge#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
PREFIX physiologicalProcess: <http://example.org/model-device-alarm-knowledge/vocab/physiological-process/>

SELECT ?label ?metricConcept ?property WHERE {
  VALUES ?target { physiologicalProcess:VascularCompliance }
  ?a a mda:AlarmType ; mda:hasLabel ?label .
  ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent)*/mda:detectsMetric ?metric .
  ?metric a ?metricConcept .
  ?metricConcept a skos:Concept .
  ?metric mda:approximates ?property .
  ?property (mda:isPropertyOf)? ?target .
}
ORDER BY ?label ?metricConcept
```

**Outcome:** 7 row(s)

| label | metricConcept | property |
|---|---|---|
| CARDIOHELP - pVen onder waarschuwingsgrens | metric:VenousPressure | physiologicalProperty:VenousPressure |
| Monitor - Hoge ARTmean | metric:ABP | physiologicalProperty:ArterialPressure |
| Monitor - Hoge ARTmean | metric:ABP_Mean | physiologicalProperty:ArterialPressure |
| Monitor - Lage ARTmean | metric:ABP | physiologicalProperty:ArterialPressure |
| Monitor - Lage ARTmean | metric:ABP_Mean | physiologicalProperty:ArterialPressure |
| PHILIPSMONITOR - ABP verkleinen | metric:ABP | physiologicalProperty:ArterialPressure |
| PHILIPSMONITOR - SpO2 lage PFI | metric:PulseFlowIndex | physiologicalProperty:TissuePerfusion |

## CQ5_identical_semantic_content

**Question:** Are there alarms with identical semantic representational content?

**Graph:** reasoned (OWL-RL closure)

```sparql
# question: Are there alarms with identical semantic representational content?
#
# Two AlarmType archetypes have "identical semantic representational content"
# when EVERYTHING their message blueprint represents matches: which concept
# each node in the tree is asserted to be (device/sensor/signal/metric
# identity — a device concept encodes its manufacturer, e.g.
# device:ExtracorporealMembraneOxygenator_CardioHelp_Getinge is NOT the same
# content as device:MechanicalVentilator_Draeger even if both merely say
# "connection lost"), the leaf VALUES asserted on those nodes
# (hasQualityState/hasRate/hasAnatomicalPosition/...), AND what the ontology
# additionally entails from all of that (operation-state propagation, the
# situational/clinical-therapeutic terminal effect). Identity of node+value is
# necessary — an earlier version of this query compared only the entailed
# terminal effect and wrongly called three different-manufacturer disconnect
# alarms "identical" because they happened to reach the same organ system;
# they are not identical, they merely share one downstream implication, which
# is a different (and weaker) question than this one asks.
#
# reasoning: required
#
# Because entailment is monotonic (the reasoner only ever ADDS facts), folding
# entailed content into a signature that already includes every asserted node
# and value can only ever make it MORE discriminating, never merge two
# archetypes that already differ in what's asserted — so "inference-logic
# included" here means the comparison is complete (it also catches archetypes
# that would coincide only once their downstream implication is accounted
# for), not that it is looser. On this catalogue the entailed facts happen to
# never end up being what SEPARATES two otherwise-identical archetypes either
# (asserted content already fully determines them), so the result is the same
# set the purely-asserted comparison found — which is the correct outcome,
# not a coincidence to explain away.
#
# Method: for each archetype, compute a "signature" — the sorted set of every
# (a) hasCategory/hasPriority on the archetype itself, (b) rdf:type of every
# node reachable via hasMessage/concernsPatient/isMonitoredBy/(hasSensor|
# hasComponent|producesSignal|detectsMetric)* — the asserted IDENTITY of each
# node, (c) hasQualityState/hasRate/hasComponentOperationState/
# hasSensorOperationState/hasDeviceOperationState/hasAnatomicalPosition
# asserted on those nodes — their asserted VALUES, (d) every entailed
# mda:hasOperationState anywhere in the tree (technical net effect, e.g. a
# component-level Disconnected propagated up to the device), and (e) the
# TERMINAL node of every situational-predicate chain out of the tree —
# approximates/isPropertyOf/presentIn/organPartOfSystem (clinical) and
# administers/targetsProcess (therapeutic), walked to where no further
# situational edge exists (FILTER NOT EXISTS), since an intermediate hop is a
# step on the way, not the effect itself. Archetypes are grouped by that
# signature; a group with more than one archetype is the CQ's positive case.

PREFIX mda: <http://example.org/model-device-alarm-knowledge#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>

SELECT (GROUP_CONCAT(?label; separator=" | ") AS ?identicalAlarms) (COUNT(DISTINCT ?a) AS ?matchCount) WHERE {
  SELECT ?a ?label (GROUP_CONCAT(?fact; separator="^") AS ?signature) WHERE {
    SELECT ?a ?label ?fact WHERE {
      ?a a mda:AlarmType ; mda:hasLabel ?label .
      {
        ?a mda:hasCategory ?v .
        BIND(CONCAT("hasCategory=", STR(?v)) AS ?fact)
      } UNION {
        ?a mda:hasPriority ?v .
        BIND(CONCAT("hasPriority=", STR(?v)) AS ?fact)
      } UNION {
        # node identity — which concept each node is asserted to be
        ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent|mda:producesSignal|mda:detectsMetric)* ?node .
        ?node rdf:type ?t .
        ?t a skos:Concept .
        BIND(CONCAT("type=", STR(?t)) AS ?fact)
      } UNION {
        # node values — the leaf facts asserted on those nodes
        ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent|mda:producesSignal|mda:detectsMetric)* ?node .
        ?node ?p ?v .
        FILTER(?p IN (mda:hasQualityState, mda:hasRate, mda:hasComponentOperationState,
                       mda:hasSensorOperationState, mda:hasDeviceOperationState, mda:hasAnatomicalPosition))
        BIND(CONCAT(STRAFTER(STR(?p), "#"), "=", STR(?v)) AS ?fact)
      } UNION {
        # net effect — entailed operation state anywhere in the tree
        ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent|mda:producesSignal|mda:detectsMetric)* ?node .
        ?node mda:hasOperationState ?v .
        BIND(CONCAT("hasOperationState=", STR(?v)) AS ?fact)
      } UNION {
        # net effect — terminal situational implication (clinical/therapeutic)
        ?a mda:hasMessage/mda:concernsPatient/mda:isMonitoredBy/(mda:hasSensor|mda:hasComponent|mda:producesSignal|mda:detectsMetric)* ?node .
        ?node (mda:approximates|mda:isPropertyOf|mda:presentIn|mda:organPartOfSystem|mda:administers|mda:targetsProcess)+ ?effect .
        FILTER NOT EXISTS { ?effect (mda:approximates|mda:isPropertyOf|mda:presentIn|mda:organPartOfSystem|mda:administers|mda:targetsProcess) ?next }
        BIND(CONCAT("effect=", STR(?effect)) AS ?fact)
      }
    }
    ORDER BY ?a ?fact
  }
  GROUP BY ?a ?label
}
GROUP BY ?signature
HAVING (COUNT(DISTINCT ?a) > 1)
```

**Outcome:** 1 row(s)

| identicalAlarms | matchCount |
|---|---|
| PHILIPSMONITOR - SpO2 geen pols \| PHILIPSMONITOR - Storing in SpO2 | 2 |
