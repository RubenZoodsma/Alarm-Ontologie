"""
cq_QA.py — base for running Competency Questions (CQs) against the curated
ontology (see ../CQ_VALIDATION_PLAN.md for what a CQ validates and why).

Loads 3_CURATION, prepares two variants of the graph — the raw base and its
OWL-RL closure — then runs every .rq file under CompetencyQuestions/ against
whichever variant that query declares it needs, and writes a Markdown report
(cq_report.md) with, per CQ: its natural-language question, the SPARQL that
answers it, and the resulting rows.

A query states its natural-language question with a leading directive
comment, alongside `# reasoning: required` (see below):

    # question: <the CQ, verbatim>

Reasoned or not, per query
---------------------------
A query that asks about an *entailed* fact (e.g. mda:approximates, only
materialised by the reasoner from inference.ttl's class-level bridge
restrictions — see that file's header) must run against the closure. A query
that only walks *asserted* structure (e.g. rdf:type straight off kg.ttl's
archetypes) must NOT: OWL-RL also derives every superclass membership (a
Philips monitor archetype ends up typed mda:Device, owl:Thing, ...), which
floods a plain "group alarms by shared rdf:type" query with meaningless
broad-category matches that don't exist in the base data. So a query opts
in explicitly with a leading directive comment:

    # reasoning: required

Its absence means "runs against the base graph" (the default, and the
common case — most CQs here ask about what kg.ttl/vocab.ttl directly assert).

CQs that need patient-level fixture data (CQ-set E) and pass/fail checking
against the plan's positive/negative cases are not wired up yet — those
build on this base.

Base graph
----------
The three files op_knowledge.py treats as the TBox (see its path-block
comment): ontology.ttl (classes/properties), vocab.ttl (SKOS vocabulary),
inference.ttl (bridge + tail axioms — required for the entailments CQ-set E
in the validation plan puts under test) — plus 3_CURATION/kg.ttl, the
archetype catalogue: reusable, hand-curated blueprints of the implicit
knowledge an alarm label carries, formalised so a CQ can reason over the
library itself (e.g. CQ5: do two archetypes carry identical content under
different labels?). A CQ that instead needs patient-level instance data
(CQ-set E's snapshot fixtures) loads that ABox on top of this base itself —
kg.ttl's archetypes are class-level blueprints, not that fixture.

Usage
-----
  python3 cq_QA.py
"""

import re
from pathlib import Path

from rdflib import Graph, Namespace, URIRef
import owlrl

REASONING_DIRECTIVE = re.compile(r"^#\s*reasoning:\s*required\s*$", re.MULTILINE)
QUESTION_DIRECTIVE = re.compile(r"^#\s*question:\s*(.+)$", re.MULTILINE)

CQ_DIR = Path(__file__).parent
ROOT = CQ_DIR.parent
CUR_DIR = ROOT / "3_CURATION"
QUERY_DIR = CQ_DIR / "CompetencyQuestions"
REPORT = CQ_DIR / "cq_report.md"

ONTOLOGY = CUR_DIR / "ontology.ttl"
VOCAB = CUR_DIR / "vocab.ttl"
INFERENCE = CUR_DIR / "inference.ttl"
CATALOGUE = CUR_DIR / "kg.ttl"

TBOX_FILES = [ONTOLOGY, VOCAB, INFERENCE]
BASE_FILES = TBOX_FILES + [CATALOGUE]

# Namespaces every CQ's SPARQL will bind against — the shared vocabulary
# (mda:) plus the named-graph snapshot scope the validation plan requires
# every CQ to use for patient isolation (§2 step 6, §5 E4): one graph per
# (patient, instant), reached via snap:forPatient. ent:/inst: mirror
# 4_OPERATIONAL/op_knowledge.py's ENTITY/INST split (persistent entities vs.
# per-alarm instances) for whatever fixture is authored against this base.
MDA = Namespace("http://example.org/model-device-alarm-knowledge#")
ENT = Namespace("http://example.org/model-device-alarm-knowledge/entity/")
INST = Namespace("http://example.org/model-device-alarm-knowledge/instance/")
SNAP = Namespace("http://example.org/model-device-alarm-knowledge/snapshot/")


def load_base() -> Graph:
    """Parse 3_CURATION's TBox + archetype catalogue into one graph, namespaces bound."""
    g = Graph()
    for f in BASE_FILES:
        g.parse(f, format="turtle")
    g.bind("mda", MDA)
    g.bind("ent", ENT)
    g.bind("inst", INST)
    g.bind("snap", SNAP)
    return g


def prepare_graph(g: Graph = None) -> Graph:
    """
    The graph CQs execute against: the base TBox (or a caller-supplied graph
    that already includes it plus fixture/ABox data), with its OWL-RL
    closure materialised in place.

    A real reasoner (owlrl), not a query-time trick — CQ-set E in the
    validation plan puts the reasoner itself under test (bridge axioms,
    property chains), so the entailments must actually be computed, not
    approximated by a cleverer SPARQL pattern.
    """
    g = load_base() if g is None else g
    owlrl.DeductiveClosure(owlrl.OWLRL_Semantics).expand(g)
    return g


def _label(term, g: Graph) -> str:
    """Readable term label: a prefixed name for URIs, the plain value otherwise."""
    if term is None:
        return "-"
    if isinstance(term, URIRef):
        try:
            return g.namespace_manager.normalizeUri(term)
        except Exception:
            return str(term)
    return str(term)


def run_query(query_path: Path, base: Graph, reasoned: Graph) -> dict:
    """
    Execute one .rq file against `reasoned` if it carries the
    `# reasoning: required` directive (see module docstring) or `base`
    otherwise. Returns everything the report needs: the CQ's question, the
    raw query text, which graph it ran against, and its result rows.
    """
    text = query_path.read_text()
    used_reasoning = bool(REASONING_DIRECTIVE.search(text))
    graph = reasoned if used_reasoning else base
    question_match = QUESTION_DIRECTIVE.search(text)

    result = graph.query(text)
    # SELECT-only helper: Result.__iter__ is typed for ASK (bool)/CONSTRUCT
    # (triple) too, so narrow to the row shape a SELECT actually yields.
    rows = [[_label(t, graph) for t in row] for row in result if not isinstance(row, bool)]
    print(f"[cq_QA] {query_path.name}: {len(rows)} row(s) ({'reasoned' if used_reasoning else 'base'})")

    return {
        "name": query_path.stem,
        "question": question_match.group(1).strip() if question_match else None,
        "query_text": text.strip(),
        "used_reasoning": used_reasoning,
        "vars": [str(v) for v in result.vars] if result.vars else [],
        "rows": rows,
    }


def _escape_cell(value: str) -> str:
    """Markdown table cells can't contain a raw '|' or newline."""
    return value.replace("|", "\\|").replace("\n", " ")


def render_markdown(base: Graph, reasoned: Graph, results: list) -> str:
    """Render the CQ run as a Markdown report: one section per CQ, each with
    its natural-language question, the SPARQL that answers it, and a table
    of the rows it returned."""
    lines = [
        "# Competency Question validation report",
        "",
        f"Base graph: {', '.join(f.name for f in BASE_FILES)} — {len(base)} triples "
        f"({len(reasoned)} after OWL-RL closure, +{len(reasoned) - len(base)} entailed).",
        "",
    ]
    for r in results:
        lines.append(f"## {r['name']}")
        lines.append("")
        if r["question"]:
            lines.append(f"**Question:** {r['question']}")
            lines.append("")
        lines.append(f"**Graph:** {'reasoned (OWL-RL closure)' if r['used_reasoning'] else 'base (asserted only)'}")
        lines.append("")
        lines.append("```sparql")
        lines.append(r["query_text"])
        lines.append("```")
        lines.append("")
        lines.append(f"**Outcome:** {len(r['rows'])} row(s)")
        lines.append("")
        if r["rows"]:
            lines.append("| " + " | ".join(r["vars"]) + " |")
            lines.append("|" + "|".join("---" for _ in r["vars"]) + "|")
            for row in r["rows"]:
                lines.append("| " + " | ".join(_escape_cell(c) for c in row) + " |")
        else:
            lines.append("_No results._")
        lines.append("")
    return "\n".join(lines)


def main() -> None:
    base = load_base()
    print(f"[cq_QA] base graph loaded from 3_CURATION: {', '.join(f.name for f in BASE_FILES)}")
    print(f"        {len(base)} triples")

    reasoned = prepare_graph(Graph() + base)
    print(f"        {len(reasoned)} triples after OWL-RL closure "
          f"(+{len(reasoned) - len(base)} entailed)")

    queries = sorted(QUERY_DIR.glob("*.rq"))
    if not queries:
        print(f"\n[cq_QA] no competency questions yet under {QUERY_DIR.relative_to(ROOT)}/")
        return

    results = [run_query(q, base, reasoned) for q in queries]
    REPORT.write_text(render_markdown(base, reasoned, results))
    print(f"\n[cq_QA] report written to {REPORT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
