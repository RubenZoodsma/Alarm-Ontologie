"""
check_delta.py — audits 3_CURATION's hand-authored files against the current
1_BASE + 2_READOUT state they were seeded from (and may since have diverged
from, in either direction).

3_CURATION stands for itself: it is never regenerated, never overwritten,
never a materializer's output. This script does not enforce anything and
changes nothing — it only reports, so a curator can see at a glance whether
an edit was a deliberate extension or an accidental drift.

Three categories, not a flat diff:
  ADDITIONS  triples only in 3_CURATION — new curated knowledge. Expected.
  DROPS      triples only in base/readout, missing from 3_CURATION —
             something upstream got silently omitted from curation.
  CHANGES    same (subject, predicate) in both, but a different object —
             base/readout says X, curation says Y instead. The case most
             worth a deliberate look: is this an intentional override, or
             did curation just drift from what generated it?

Blank nodes are compared structurally (rdflib.compare, graph isomorphism),
not by their arbitrary per-parse identifiers — a naive triple-set diff would
report every blank-node existential in kg.ttl and every OWL restriction in
vocab.ttl's pre-coordinated concepts as a spurious drop+addition pair on
every single run, burying anything that actually matters.

Usage
-----
  python3 check_delta.py
"""

from pathlib import Path

from rdflib import Graph
from rdflib.compare import graph_diff

CUR_DIR = Path(__file__).parent
ROOT = CUR_DIR.parent
BASE_DIR = ROOT / "1_BASE"
READOUT_DIR = ROOT / "2_READOUT"
OUTCOME_DIR = READOUT_DIR / "outcome"

CURATION_FILES = [CUR_DIR / "ontology.ttl", CUR_DIR / "vocab.ttl", CUR_DIR / "kg.ttl"]
# inference.ttl and clinical_{axioms,vocab}.ttl are deliberately NOT listed
# here: their content is already hand-merged into 3_CURATION/ontology.ttl and
# vocab.ttl (see op_knowledge.py's path-block comment), and all three now live
# under 2_READOUT/.../old/ as retired snapshots. Diffing against those old
# copies would just re-confirm they match — the content they contributed is
# exactly what should surface as ADDITIONS below (curated knowledge with no
# mechanical upstream source), not be excluded from the comparison.
UPSTREAM_FILES = [
    BASE_DIR / "ontology.ttl", BASE_DIR / "vocab_base.ttl",
    OUTCOME_DIR / "vocab_generated.ttl", OUTCOME_DIR / "kg_generated.ttl",
]


def load(paths) -> Graph:
    g = Graph()
    for p in paths:
        g.parse(p, format="turtle")
    return g


def _label(term, g: Graph) -> str:
    """Readable term label using a prefixed name where the graph has one bound."""
    try:
        return g.namespace_manager.normalizeUri(term)
    except Exception:
        return str(term)


def report(title: str, triples: list, g: Graph, cap: int = 200) -> None:
    print(f"\n{title} ({len(triples)})")
    if not triples:
        return
    ordered = sorted(triples, key=lambda t: tuple(_label(x, g) for x in t))
    for s, p, o in ordered[:cap]:
        print(f"    {_label(s, g)}  {_label(p, g)}  {_label(o, g)}")
    if len(triples) > cap:
        print(f"    … {len(triples) - cap} more, truncated")


def main() -> None:
    cur = load(CURATION_FILES)
    upstream = load(UPSTREAM_FILES)
    both, upstream_only, cur_only = graph_diff(upstream, cur)
    upstream_only, cur_only = list(upstream_only), list(cur_only)

    # A "change" is a (subject, predicate) pair present in both diff sides —
    # base/readout asserts some value there, curation asserts a different one.
    upstream_sp = {(s, p) for s, p, _ in upstream_only}
    cur_sp = {(s, p) for s, p, _ in cur_only}
    changed_sp = upstream_sp & cur_sp

    pure_drops = [(s, p, o) for s, p, o in upstream_only if (s, p) not in changed_sp]
    pure_additions = [(s, p, o) for s, p, o in cur_only if (s, p) not in changed_sp]

    print("[check_delta] 3_CURATION vs 1_BASE+2_READOUT")
    print(f"  curation:  {len(cur)} triples across {', '.join(f.name for f in CURATION_FILES)}")
    print(f"  upstream:  {len(upstream)} triples across {len(UPSTREAM_FILES)} file(s)")
    print(f"  shared:    {len(both)} triples (structurally identical, blank nodes included)")

    report("ADDITIONS — only in 3_CURATION", pure_additions, cur)
    report("DROPS — only in base/readout, missing from 3_CURATION", pure_drops, upstream)

    print(f"\nCHANGES — same (subject, predicate), different value ({len(changed_sp)})")
    if changed_sp:
        upstream_by_sp, cur_by_sp = {}, {}
        for s, p, o in upstream_only:
            if (s, p) in changed_sp:
                upstream_by_sp.setdefault((s, p), []).append(o)
        for s, p, o in cur_only:
            if (s, p) in changed_sp:
                cur_by_sp.setdefault((s, p), []).append(o)
        for s, p in sorted(changed_sp, key=lambda sp: tuple(_label(x, cur) for x in sp)):
            print(f"    {_label(s, cur)}  {_label(p, cur)}")
            for o in upstream_by_sp.get((s, p), []):
                print(f"      - base/readout: {_label(o, upstream)}")
            for o in cur_by_sp.get((s, p), []):
                print(f"      + curated:      {_label(o, cur)}")


if __name__ == "__main__":
    main()
