"""
promote_new.py — additively promote NEW alarm archetypes and the vocabulary
concepts they reference from 2_READOUT/outcome/{kg_generated.ttl,
vocab_generated.ttl} into 3_CURATION/{kg.ttl,vocab.ttl}.

3_CURATION is hand-authored and never mechanically overwritten (see
check_delta.py's header). This script respects that: it only ADDS whole
mda:AlarmType archetypes that do not exist in 3_CURATION/kg.ttl at all yet,
plus the vocabulary concepts those archetypes reference that are not yet in
3_CURATION/vocab.ttl. It never touches a triple for anything already
present, so an already-curated AlarmType or concept is left byte-for-byte
as curation left it — including any CHANGES a curator already made (those
only show up in check_delta.py's report, on purpose; this script cannot
see or resolve them). Run check_delta.py after promoting to review the
result and to see what, if anything, still needs a curator's judgment.

Why not a plain graph union
----------------------------
kg_generated.ttl is regenerated from scratch on every vocab_readout.py run,
minting a FRESH BNode() for every individuated node. A raw union of an
already-curated AlarmType's triples with its re-generated counterpart would
give that one AlarmType two Device blank nodes, two Sensor blank nodes,
etc. — silently duplicating structure. Each NEW AlarmType's root IRI is
stable (a pure function of label+priority — alarmtype_iri in
vocab_readout.py), but a graph union only avoids duplication where the
subject side is the same in both graphs; for the 15 archetypes 3_CURATION
already has, it is not. So instead of unioning, this script copies each
new archetype's full reachable subgraph (BFS through blank nodes only —
concept IRIs are shared and structurally stable across runs, so recursion
stops there) wholesale out of kg_generated.ttl, and does the same for any
vocabulary concept it references that is not yet in vocab.ttl, repeating
transitively (a precoordinated concept can itself reference another new
concept, e.g. a manufacturer refinement).

Usage
-----
  python3 promote_new.py             # apply, overwrite kg.ttl and vocab.ttl
  python3 promote_new.py --dry-run   # report counts only, write nothing
"""

import sys
from pathlib import Path

from rdflib import BNode, Graph, Namespace, URIRef
from rdflib.namespace import RDF

CUR_DIR = Path(__file__).parent
ROOT = CUR_DIR.parent
OUTCOME_DIR = ROOT / "2_READOUT" / "outcome"

CUR_KG_PATH = CUR_DIR / "kg.ttl"
CUR_VOCAB_PATH = CUR_DIR / "vocab.ttl"
GEN_KG_PATH = OUTCOME_DIR / "kg_generated.ttl"
GEN_VOCAB_PATH = OUTCOME_DIR / "vocab_generated.ttl"

MDA = Namespace("http://example.org/model-device-alarm-knowledge#")
VOCAB_NS = "http://example.org/model-device-alarm-knowledge/vocab/"

HEADER = (
    "# 3_CURATION/{name} — HAND-AUTHORED. Stands for itself.\n"
    "#\n"
    "# Extended by promote_new.py: new archetypes/concepts from\n"
    "# 2_READOUT/outcome were additively merged in. Existing curated\n"
    "# content above this line's original triples is untouched.\n"
    "# Cross-check against upstream with 3_CURATION/check_delta.py.\n\n"
)


def reachable(g: Graph, root) -> Graph:
    """All triples reachable from `root`, expanding through blank nodes only —
    concept IRIs are shared/stable, so recursion stops there by design."""
    sub = Graph()
    seen, frontier = set(), [root]
    while frontier:
        n = frontier.pop()
        if n in seen:
            continue
        seen.add(n)
        for p, o in g.predicate_objects(n):
            sub.add((n, p, o))
            if isinstance(o, BNode) and o not in seen:
                frontier.append(o)
    return sub


def vocab_refs(triples: Graph) -> set:
    """Vocabulary-scheme concept IRIs referenced as objects in `triples`."""
    return {o for _, _, o in triples if isinstance(o, URIRef) and str(o).startswith(VOCAB_NS)}


def has_any_triple(g: Graph, node) -> bool:
    return next(g.predicate_objects(node), None) is not None


def main() -> None:
    dry_run = "--dry-run" in sys.argv

    cur_kg = Graph(); cur_kg.parse(CUR_KG_PATH, format="turtle")
    cur_vocab = Graph(); cur_vocab.parse(CUR_VOCAB_PATH, format="turtle")
    gen_kg = Graph(); gen_kg.parse(GEN_KG_PATH, format="turtle")
    gen_vocab = Graph(); gen_vocab.parse(GEN_VOCAB_PATH, format="turtle")

    existing_types = set(cur_kg.subjects(RDF.type, MDA.AlarmType))
    generated_types = set(gen_kg.subjects(RDF.type, MDA.AlarmType))
    new_types = sorted(generated_types - existing_types, key=str)

    kg_additions = Graph()
    for t in new_types:
        kg_additions += reachable(gen_kg, t)

    # Transitively promote referenced vocabulary concepts not yet curated.
    vocab_additions = Graph()
    promoted = set()
    frontier = {c for c in vocab_refs(kg_additions) if not has_any_triple(cur_vocab, c)}
    while frontier:
        nxt = set()
        for c in frontier:
            if c in promoted:
                continue
            promoted.add(c)
            sub = reachable(gen_vocab, c)
            vocab_additions += sub
            nxt |= {r for r in vocab_refs(sub) if r not in promoted and not has_any_triple(cur_vocab, r)}
        frontier = nxt

    print(f"[promote] {len(existing_types)} existing AlarmType(s), "
          f"{len(generated_types)} in outcome, {len(new_types)} new")
    for t in new_types:
        label = next(gen_kg.objects(t, MDA.hasLabel), t)
        print(f"          + {label}")
    print(f"[promote] {len(promoted)} new vocabulary concept(s)")
    print(f"[promote] +{len(kg_additions)} kg triple(s), +{len(vocab_additions)} vocab triple(s)")

    if dry_run:
        print("[promote] --dry-run: nothing written")
        return

    if not new_types:
        print("[promote] nothing to do")
        return

    out_kg = cur_kg + kg_additions
    out_vocab = cur_vocab + vocab_additions
    for prefix, ns in list(gen_kg.namespaces()):
        out_kg.bind(prefix, ns, override=False)
    for prefix, ns in list(gen_vocab.namespaces()):
        out_vocab.bind(prefix, ns, override=False)

    CUR_KG_PATH.write_text(HEADER.format(name="kg.ttl") + out_kg.serialize(format="turtle"),
                            encoding="utf-8")
    CUR_VOCAB_PATH.write_text(HEADER.format(name="vocab.ttl") + out_vocab.serialize(format="turtle"),
                               encoding="utf-8")
    print(f"[promote] wrote {CUR_KG_PATH.name} ({len(out_kg)} triples), "
          f"{CUR_VOCAB_PATH.name} ({len(out_vocab)} triples)")


if __name__ == "__main__":
    main()
