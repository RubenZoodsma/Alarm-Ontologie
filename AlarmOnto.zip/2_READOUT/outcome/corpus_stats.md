Table XXX. Alarm corpus specifications and annotation characteristics.

|  | Neonatal ICU | Paediatric ICU | Adult ICU | Total study population* |
|---|---|---|---|---|
| **Initial alarms, n** | 10846787 | 2973755 | 340410 | 14160952 |
| Unique alarm labels, n | 280 | 412 | 361 | 886 |
| &nbsp;&nbsp;CardiacMonitor | - | - | 67 | 67 |
| &nbsp;&nbsp;Dialysator | - | 2 | - | 2 |
| &nbsp;&nbsp;ExtracorporealMembraneOxygenator | - | - | 32 | 32 |
| &nbsp;&nbsp;Incubator | 24 | - | - | 24 |
| &nbsp;&nbsp;MechanicalVentilator | 48 | 78 | 70 | 196 |
| &nbsp;&nbsp;PhysiologicalMonitor | 207 | 331 | 192 | 564 |
| &nbsp;&nbsp;Thermoregulator | 1 | 1 | - | 1 |
| Alarm priority, n (unique alarms) | | | | |
| &nbsp;&nbsp;Low | 47 | 84 | - | 92 |
| &nbsp;&nbsp;Medium | 163 | 238 | - | 293 |
| &nbsp;&nbsp;High | 70 | 90 | - | 140 |
| &nbsp;&nbsp;Unknown | - | - | 361 | 361 |
| **Alarm corpus after feasibility split (50th percentile)** | | | | |
| Unique alarm labels, n | 17 | 25 | 17 | 55 |
| &nbsp;&nbsp;CardiacMonitor | - | - | 1 | 1 |
| &nbsp;&nbsp;Dialysator | - | 1 | - | 1 |
| &nbsp;&nbsp;ExtracorporealMembraneOxygenator | - | - | 2 | 2 |
| &nbsp;&nbsp;Incubator | 8 | - | - | 8 |
| &nbsp;&nbsp;MechanicalVentilator | 3 | 12 | 9 | 24 |
| &nbsp;&nbsp;PhysiologicalMonitor | 5 | 11 | 5 | 18 |
| &nbsp;&nbsp;Thermoregulator | 1 | 1 | - | 1 |
| Alarm priority, n (unique alarms) | | | | |
| &nbsp;&nbsp;Low | 2 | 4 | - | 5 |
| &nbsp;&nbsp;Medium | 9 | 9 | - | 17 |
| &nbsp;&nbsp;High | 6 | 12 | - | 16 |
| &nbsp;&nbsp;Unknown | - | - | 17 | 17 |
| **Annotation characteristics** | | | | |
| Relevant concepts, median[IQR] | 10[7-11] | 10[8-12] | 11[8-12] | 10[7-12] |
| Clinically enriched, median[IQR] | 2[2-2] | 2[1-3] | 2[1-3] | 2[2-3] |
| Technically enriched, median[IQR] | 6[4-8] | 8[5-8] | 8[5-8] | 8[5-8] |
| Annotated triples, median[IQR] | 9[6-10] | 10[7-11] | 10[7-11] | 10[6-11] |

*The total study population alarm count is not equal to the sum of the three individual ICUs due to overlap in alarm occurrence between them.