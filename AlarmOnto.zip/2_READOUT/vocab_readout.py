"""
vocab_readout.py

Ontology-driven readout script for vocab_data.csv.

Analyzes vocab_data.csv against the hand-maintained base files in 1_BASE/
and fully regenerates two output files into 2_READOUT/outcome/ — data.csv
and this script are the *initial data*; everything outcome/ holds, generated
or hand-authored, is what the readout produced from it:

  outcome/vocab_generated.ttl   every SKOS concept required by the CSV that
                        is not yet present in vocab_base.ttl (auto-generated
                        scheme expansion, for expert review)
  outcome/kg_generated.ttl      one mda:AlarmType archetype per CSV row, with
                        blank-node existential structure ("some device of
                        this type, carrying some sensor of this type, ...")

The nesting of the generated KG is NOT hard-coded.  It is derived at
runtime from 1_BASE/ontology.ttl:

  1. Object properties with a named rdfs:domain and rdfs:range span a
     class tree, discovered by breadth-first search from mda:Alarm
     (inverse/cyclic edges are pruned; genuine ambiguity aborts the run).
  2. mda:instantiatesClass binds a concept scheme to the class its
     concepts specialise — a "node column": the concept becomes the
     rdf:type of a blank node of that class (device, sensor, signal, ...).
  3. mda:valuesFromScheme binds an object property to the scheme its
     values are drawn from — a "leaf column": the concept becomes the
     property's object on the node of the property's domain class
     (priority, category, ...).

Intermediate classes on a path (e.g. AlarmMessage between Alarm and its
category) are materialized automatically, so ontology rules like
"category always sits on an AlarmMessage node" are enforced by the
ontology itself, not by this script.

Adding a new (nested) CSV column therefore requires NO change to the
triple builder: declare the class and property in ontology.ttl, add the
scheme binding there, add the scheme to vocab_base.ttl, and map the CSV
column name to its scheme namespace in COLUMN_SCHEMES below.

Usage
-----
  python3 vocab_readout.py

Both outputs are pure functions of (ontology.ttl, vocab_base.ttl,
vocab_data.csv): they are rewritten from scratch on every run, never
appended to.

Two distinct promotion paths exist for a generated stub, and they are not
interchangeable. Adding a notation directly to vocab_base.ttl (checked by
build_notation_index/collect_missing below) marks it as truly universal,
timeless scaffold — rare, and this script stops re-generating a stub for it
on the next run. The much more common path is 3_CURATION: a stub gets
reviewed, enriched, and possibly redefined there instead, as a *catalogue-
scoped* curated concept. This script deliberately does NOT check 3_CURATION
before generating — that would make stage 2 depend on stage 3, breaking the
pipeline's one-way ordering — so a promoted concept's stub keeps being
regenerated here too. That is harmless surplus, not drift: 4_OPERATIONAL
reads 3_CURATION exclusively, never this file's output directly, and
3_CURATION/check_delta.py is the tool for seeing where curation has
knowingly diverged from what this script still (mechanically, correctly)
produces.
"""

import re
import sys
from pathlib import Path

import pandas as pd
from rdflib import Graph, URIRef, Literal, BNode, Namespace
from rdflib.collection import Collection
from rdflib.namespace import RDF, RDFS, OWL, SKOS

sys.path.append(str(Path(__file__).resolve().parent.parent))
from ontology_tree import derive_class_tree, format_tree, local as _local

# ── Paths ─────────────────────────────────────────────────────────────────────

READOUT_DIR     = Path(__file__).parent
ONTO_DIR        = READOUT_DIR.parent
ONTOLOGY_PATH   = ONTO_DIR / "1_BASE" / "ontology.ttl"
VOCAB_BASE_PATH = ONTO_DIR / "1_BASE" / "vocab_base.ttl"
CSV_PATH        = ONTO_DIR / "2_READOUT" / "data" / "annotated" / "p50_annotated.csv"
OUTCOME_DIR     = READOUT_DIR / "outcome"
VOCAB_OUT_PATH  = OUTCOME_DIR / "vocab_generated.ttl"
KG_OUT_PATH     = OUTCOME_DIR / "kg_generated.ttl"

# ── Namespaces ────────────────────────────────────────────────────────────────

MDA       = Namespace("http://example.org/model-device-alarm-knowledge#")
ALARMTYPE = Namespace("http://example.org/model-device-alarm-knowledge/alarmtype/")
VOCAB     = "http://example.org/model-device-alarm-knowledge/vocab/"

# Root of the class tree used for path-finding.  Domains in the ontology are
# asserted on mda:Alarm; the emitted root individuals are typed mda:AlarmType.
ROOT_CLASS = MDA.Alarm

# ── Column configuration ─────────────────────────────────────────────────────
# LABEL_COLUMN holds the alarm label (mda:hasLabel + IRI minting, together
# with PRIORITY_COLUMN).  COLUMN_SCHEMES is the ONLY per-column vocabulary
# configuration: which concept scheme a CSV column draws from.  Everything
# else (attachment property or class, nesting position, broader concept for
# stubs) is derived from ontology.ttl and vocab_base.ttl.  The dotted column
# names ("Sensor.AnatomicalPosition") are documentation for the reader; the
# actual attachment always comes from the ontology bindings.  Columns listed
# here but absent from the CSV are ignored; CSV columns not listed here are
# reported as a warning.

LABEL_COLUMN    = "alarmLabel"
PRIORITY_COLUMN = "alarmPriority"

COLUMN_SCHEMES = {
    "alarmPriority":             ("alarmprio",             VOCAB + "alarm-priority/"),
    "alarmCategory":             ("alarmcat",              VOCAB + "alarm-category/"),
    "Device":                    ("device",                VOCAB + "device/"),
    "Device.Type":               ("deviceType",            VOCAB + "device-type/"),
    "Device.Manufacturer":       ("manufacturer",          VOCAB + "manufacturer/"),
    "Device.OperationalState":   ("opstate",               VOCAB + "operation-state/"),
    "Component":                 ("component",             VOCAB + "component/"),
    "Component.OperationalState":("opstate",               VOCAB + "operation-state/"),
    "Sensor":                    ("sensor",                VOCAB + "sensor/"),
    "Sensor.OperationalState":   ("opstate",               VOCAB + "operation-state/"),
    "Sensor.AnatomicalPosition": ("anatomicalPosition",    VOCAB + "anatomical-position/"),
    "Sensor.Laterality":         ("laterality",            VOCAB + "laterality/"),
    "Signal":                    ("signal",                VOCAB + "signal/"),
    "Signal.QualityState":       ("qualitystate",          VOCAB + "quality-state/"),
    "Metric":                    ("metric",                VOCAB + "metric/"),
    "Metric.Phase":              ("metricPhase",           VOCAB + "metric-phase/"),
    "Metric.Rate":               ("metricRate",            VOCAB + "metric-rate/"),
    "Metric.Rhythm":             ("rhythm",                VOCAB + "rhythm/"),
    "PhysiologicalProperty":     ("physiologicalProperty", VOCAB + "physiological-property/"),
    "PhysiologicalProcess":      ("physiologicalProcess",  VOCAB + "physiological-process/"),
    "Organ":                     ("organ",                 VOCAB + "organ/"),
    "OrganSystem":               ("organSystem",           VOCAB + "organ-system/"),
    "Patient":                   ("patient",               VOCAB + "patient/"),
    "TherapeuticModality":       ("therapeuticModality",   VOCAB + "therapeutic-modality/"),
}


# ── Scheme binding derivation ─────────────────────────────────────────────────

# Some columns share a vocabulary scheme with sibling columns but must attach
# through a DIFFERENT property each (Device.OperationalState,
# Sensor.OperationalState, and Component.OperationalState all draw values
# from opstate:Scheme, but each attaches via its own single-domain
# sub-property of mda:hasOperationState — see 1_BASE/ontology.ttl). A scheme
# bound to more than one property is genuinely ambiguous from the ontology
# alone, so those columns are listed here explicitly; every other column has
# exactly one property per scheme and is resolved automatically below.
COLUMN_PROPERTY_OVERRIDE = {
    "Device.OperationalState":    MDA.hasDeviceOperationState,
    "Sensor.OperationalState":    MDA.hasSensorOperationState,
    "Component.OperationalState": MDA.hasComponentOperationState,
}


def derive_bindings(onto: Graph, columns: list) -> dict:
    """
    For each CSV column, derive how its concepts attach to the KG:

      ("node", None, class, scheme)   concept types a blank node of `class`
      ("leaf", prop, domain, scheme)  concept is the object of `prop` on
                                      the node of `domain`

    from mda:instantiatesClass / mda:valuesFromScheme in the ontology, or
    COLUMN_PROPERTY_OVERRIDE above where a scheme is shared by more than one
    property.
    """
    bindings = {}
    for col in columns:
        prefix, base_uri = COLUMN_SCHEMES[col]
        scheme = Namespace(base_uri)["Scheme"]

        override = COLUMN_PROPERTY_OVERRIDE.get(col)
        if override is not None:
            domains = [d for d in onto.objects(override, RDFS.domain) if isinstance(d, URIRef)]
            if len(domains) != 1:
                raise ValueError(
                    f"Column '{col}' overrides to {_local(override)}, which "
                    f"needs exactly one named rdfs:domain."
                )
            bindings[col] = ("leaf", override, domains[0], scheme)
            continue

        props   = sorted(onto.subjects(MDA.valuesFromScheme, scheme))
        classes = sorted(onto.objects(scheme, MDA.instantiatesClass))

        if props and classes:
            raise ValueError(
                f"Scheme {prefix}:Scheme is bound both via mda:valuesFromScheme "
                f"and mda:instantiatesClass — it must be one or the other."
            )
        if len(props) > 1 or len(classes) > 1:
            raise ValueError(f"Scheme {prefix}:Scheme has multiple bindings in ontology.ttl.")

        if props:
            prop = props[0]
            domains = [d for d in onto.objects(prop, RDFS.domain) if isinstance(d, URIRef)]
            if len(domains) != 1:
                raise ValueError(
                    f"Cannot determine a unique attachment class for {_local(prop)} "
                    f"(column '{col}'): it needs exactly one named rdfs:domain."
                )
            bindings[col] = ("leaf", prop, domains[0], scheme)
        elif classes:
            bindings[col] = ("node", None, classes[0], scheme)
        else:
            raise ValueError(
                f"No binding for column '{col}': assert either "
                f"'?property mda:valuesFromScheme {prefix}:Scheme' or "
                f"'{prefix}:Scheme mda:instantiatesClass ?class' in ontology.ttl."
            )
    return bindings


# ── Notation → IRI lookup (scheme-scoped) ─────────────────────────────────────

def build_notation_index(*graphs: Graph) -> dict:
    """Return {(scheme, notation): concept} over all given graphs."""
    index = {}
    for g in graphs:
        for concept, notation in g.subject_objects(SKOS.notation):
            for scheme in g.objects(concept, SKOS.inScheme):
                index[(scheme, str(notation))] = concept
    return index


def resolve(scheme: URIRef, notation: str, index: dict, column: str) -> URIRef:
    """Resolve a notation within its scheme, raising clearly on miss."""
    iri = index.get((scheme, notation))
    if iri is None:
        raise KeyError(
            f"No concept with skos:notation '{notation}' in scheme "
            f"<{scheme}> (column: {column})."
        )
    return iri


# ── Vocabulary expansion ──────────────────────────────────────────────────────

def _human_label(notation: str) -> str:
    """
    Convert a CamelCase notation to a human-readable label.
    'BPSensor'             → 'BP Sensor'
    'PhysiologicalMonitor' → 'Physiological Monitor'
    """
    spaced = re.sub(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ", notation)
    return spaced.strip()


# Characters that cannot appear in an IRI local name (would break the
# generated concept IRI and its Turtle serialization).
_INVALID_NOTATION = re.compile(r"[\s<>\"{}|\^`\\]")


def validate_notations(df: pd.DataFrame, columns: list) -> None:
    """
    Abort with a clear, aggregated error if any vocabulary cell holds a
    value that cannot become a valid IRI local name (e.g. contains a
    space).  Fails loudly here instead of crashing later in rdflib
    serialization.
    """
    bad = []
    for col in columns:
        for i, val in df[col].dropna().items():
            v = str(val).strip()
            if v and _INVALID_NOTATION.search(v):
                bad.append(f"  row {i + 2}, column '{col}': '{v}'")
    if bad:
        raise ValueError(
            "Invalid notation value(s) — a vocabulary cell contains "
            "whitespace or an IRI-illegal character:\n" + "\n".join(bad) +
            "\nFix these in the source CSV (e.g. 'Critical decrease' → "
            "'CriticalDecrease')."
        )


def collect_missing(df: pd.DataFrame, columns: list, bindings: dict, index: dict) -> list:
    """Return (notation, column) pairs present in df but absent from index."""
    missing = []
    for col in columns:
        scheme = bindings[col][3]
        for val in df[col].dropna().str.strip().unique():
            if val and (scheme, val) not in index:
                missing.append((val, col))
    return missing


def build_vocab_graph(missing: list, bindings: dict, base: Graph) -> Graph:
    """Build the auto-generated SKOS expansion graph for all missing notations."""
    g = Graph()
    g.bind("mda", MDA)
    g.bind("skos", SKOS)
    g.bind("rdfs", RDFS)
    for prefix, base_uri in COLUMN_SCHEMES.values():
        g.bind(prefix, Namespace(base_uri))

    for notation, column in sorted(missing, key=lambda m: (m[1], m[0])):
        kind, _, cls, scheme = bindings[column]
        ns    = Namespace(COLUMN_SCHEMES[column][1])
        c_iri = ns[notation]
        label = _human_label(notation)
        top   = next(base.subjects(SKOS.topConceptOf, scheme), None)

        g.add((c_iri, RDF.type, SKOS.Concept))
        g.add((c_iri, SKOS.inScheme, scheme))
        if top is not None:
            g.add((c_iri, SKOS.broader, top))
        if kind == "node":
            g.add((c_iri, RDFS.subClassOf, cls))
        g.add((c_iri, SKOS.prefLabel, Literal(label, lang="en")))
        # Dutch placeholder — edit manually for a real translation
        g.add((c_iri, SKOS.prefLabel, Literal(label, lang="nl")))
        g.add((c_iri, SKOS.definition, Literal(label, lang="en")))
        g.add((c_iri, SKOS.definition, Literal(label, lang="nl")))
        g.add((c_iri, SKOS.notation, Literal(notation)))

    return g


# ── KG expansion ──────────────────────────────────────────────────────────────
#
# Every node in an alarm archetype is classified (from mda:nodeKind in the
# ontology) as one of:
#
#   individuated  physical particular → a fresh per-alarm node (blank now,
#                 entity IRI after grounding).  Stays in the KG graph.
#   referential   conceptual universal → the concept IRI is used directly;
#                 its onward relations are concept-to-concept and therefore
#                 deduplicate across alarms.  These go to the VOCAB graph.
#   stateful      a hinge (Metric): identity is a pre-coordinated universal
#                 concept (base + mda:refinesUniversalIdentity leaves such as
#                 phase), but each alarm gets a thin per-alarm instance
#                 carrying its state (rate/rhythm).  Concept + tail → VOCAB;
#                 instance → KG.
#   structural    a class with no vocabulary scheme (e.g. AlarmMessage) →
#                 a per-alarm blank node typed by the class itself.  KG.

KIND_OF = {
    MDA.Individuated: "individuated",
    MDA.Referential:  "referential",
    MDA.Stateful:     "stateful",
}


def alarmtype_iri(label: str, priority: str) -> URIRef:
    """
    Generate a stable alarm type IRI from label + priority.
    'HR High' + 'High' → alarmtype:HrHigh_High
    """
    clean_label    = re.sub(r"[^A-Za-z0-9]+", "", label.title().replace(" ", ""))
    clean_priority = re.sub(r"[^A-Za-z0-9]+", "_", priority).strip("_")
    return ALARMTYPE[f"{clean_label}_{clean_priority}"]


def _is_shared(node) -> bool:
    """True for a concept IRI (deduplicable); False for a per-alarm node."""
    return isinstance(node, URIRef) and not str(node).startswith(str(ALARMTYPE))


def _scheme_of(concept: URIRef) -> URIRef:
    """The <ns>/Scheme IRI for a concept in namespace <ns>/."""
    return URIRef(str(concept).rsplit("/", 1)[0] + "/Scheme")


def _specialised_iri(base: URIRef, refinements: list) -> URIRef:
    """
    Pre-coordinate a base concept with its identity refinements into a
    single stable IRI:  metric:ABP + phase Mean → metric:ABP_Mean.
    The phase lives in a triple, not only in the name.
    """
    ns, local = str(base).rsplit("/", 1)
    suffix = "_".join(
        re.sub(r"[^A-Za-z0-9]+", "", _local(c))
        for _, c in sorted(refinements, key=lambda r: str(r[0]))
    )
    return URIRef(f"{ns}/{local}_{suffix}")


def _restriction(ref: Graph, prop: URIRef, value: URIRef) -> BNode:
    r = BNode()
    ref.add((r, RDF.type, OWL.Restriction))
    ref.add((r, OWL.onProperty, prop))
    ref.add((r, OWL.hasValue, value))
    return r


def precoordinate(ref: Graph, concept: URIRef, refs: list) -> URIRef:
    """
    Pre-coordinate `concept` with its identity refinements (mda:refinesUniversal
    Identity leaves, e.g. Metric.hasPhase or Device.hasManufacturer) into one
    shared, deduplicated universal concept — the mechanism behind e.g.
    metric:ABP + phase Mean → metric:ABP_Mean, generalised to any node-column
    class, not only Stateful ones.

    Gives the pre-coordinated concept a full OWL definition rather than a bare
    IRI, so a reasoner recognises it both ways:

      sc rdfs:subClassOf concept                       necessary: every
                                                         PhilipsMonitor is a
                                                         PhysiologicalMonitor
      sc owl:equivalentClass [intersectionOf (concept   necessary AND
             restriction...)]                           sufficient: anything
                                                          that IS a
                                                          PhysiologicalMonitor
                                                          made by Philips is
                                                          thereby entailed a
                                                          PhilipsMonitor too
      sc <refining-prop> <refining-value>               plain triple, for
                                                         direct readability/
                                                         querying without a
                                                         reasoner

    The equivalentClass direction is unlike clinical_axioms.ttl's bridge
    axioms deliberately: those encode external medical knowledge no CSV row
    contains, so they can only assert necessary conditions by hand. This
    concept's necessary AND sufficient conditions are both already fully
    known — they are exactly the CSV cells that built `refs` — so defining it
    costs nothing extra and is the more complete, more correct OWL modelling
    choice.

    This is a GENERATED stub, same as everything else in vocab_generated.ttl:
    subject to expert review, and superseded the moment it is hand-promoted
    into a curated file with its own richer definition — regenerating never
    overwrites a promoted concept, it just stops re-emitting the stub (see
    module docstring).

    Deduplicates by construction: `sc`'s IRI is a pure function of
    (concept, refs), so two rows needing the same pre-coordinated concept
    produce the same IRI — but the OWL definition below is built from fresh
    blank nodes on every call, which plain triple-set dedup cannot collapse,
    so a second call for an already-registered `sc` is a deliberate no-op
    rather than a second (redundant, blank-node-distinct) definition.
    """
    sc = _specialised_iri(concept, refs)
    if (sc, OWL.equivalentClass, None) in ref:
        return sc

    ref.add((sc, RDF.type, SKOS.Concept))
    ref.add((sc, SKOS.inScheme, _scheme_of(concept)))
    ref.add((sc, SKOS.broader, concept))
    ref.add((sc, SKOS.notation, Literal(_local(sc))))
    ref.add((sc, SKOS.prefLabel, Literal(_human_label(_local(sc)), lang="en")))
    ref.add((sc, RDFS.subClassOf, concept))

    for p_r, cval in refs:
        ref.add((sc, p_r, cval))

    members = BNode()
    Collection(ref, members,
               [concept] + [_restriction(ref, p_r, cval) for p_r, cval in refs])
    definition = BNode()
    ref.add((definition, RDF.type, OWL.Class))
    ref.add((definition, OWL.intersectionOf, members))
    ref.add((sc, OWL.equivalentClass, definition))

    return sc


def build_alarmtype_triples(row: pd.Series, kg: Graph, ref: Graph, index: dict,
                            tree: dict, node_kind: dict, node_columns: dict,
                            leaf_specs: list, target_types: dict) -> None:
    """
    Emit one CSV row as an mda:AlarmType, routing triples to two graphs:
    per-alarm particulars to `kg`, deduplicable universals to `ref`.
    """
    label  = str(row[LABEL_COLUMN]).strip()
    at_iri = alarmtype_iri(label, str(row.get(PRIORITY_COLUMN, "")).strip())
    kg.add((at_iri, RDF.type, MDA.AlarmType))
    kg.add((at_iri, MDA.hasLabel, Literal(label, lang="en")))

    def cell(col):
        if not col:
            return None
        v = row.get(col)
        if v is None or pd.isna(v) or not str(v).strip():
            return None
        return str(v).strip()

    def column_concept(cls):
        """Vocabulary concept named by cls's node-column in this row, or None."""
        col = node_columns.get(cls)
        v = cell(col)
        if v is None:
            return None
        return resolve(_scheme_of_column(col), v, index, col)

    def _scheme_of_column(col):
        return Namespace(COLUMN_SCHEMES[col][1])["Scheme"]

    def identity_refinements(cls):
        """(property, concept) pairs from mda:refinesUniversalIdentity leaves of cls."""
        refs = []
        for dcls, prop, col, role, scheme in leaf_specs:
            if dcls == cls and role == "identity":
                v = cell(col)
                if v is not None:
                    refs.append((prop, resolve(scheme, v, index, col)))
        return refs

    nodes = {ROOT_CLASS: at_iri}   # in-node: object of the incoming link
    out   = {ROOT_CLASS: at_iri}   # out-node: subject of outgoing links

    def resolve_node(cls):
        if cls in nodes:
            return
        link = tree.get(cls)
        if link is None:
            raise KeyError(
                f"No path from {_local(ROOT_CLASS)} to {_local(cls)} in the "
                f"ontology — assert the connecting property's domain/range."
            )
        parent_cls, prop = link
        resolve_node(parent_cls)

        kind    = node_kind.get(cls)          # None → structural
        concept = column_concept(cls)

        if kind == "individuated":
            b = BNode(); nodes[cls] = b; out[cls] = b
            # Identity-refining leaves (e.g. Device.hasManufacturer) pre-
            # coordinate the concept the node is typed by, exactly as for a
            # Stateful class — an individuated node still needs its own
            # per-alarm particular (out[cls] stays the blank node `b`, never
            # the concept: downstream edges like hasSensor must stay per-
            # alarm, not deduplicate), but WHICH concept it is typed by can
            # still be the pre-coordinated one.
            refs = identity_refinements(cls) if concept is not None else []
            if refs:
                concept = precoordinate(ref, concept, refs)
            # a data-valued node is typed by its concept; a structural
            # existential (e.g. the patient message-root, no CSV column) is
            # typed by its own class.
            kg.add((b, RDF.type, concept if concept is not None else cls))

        elif kind == "stateful":
            b = BNode(); nodes[cls] = b
            refs = identity_refinements(cls) if concept is not None else []
            if concept is None:
                out[cls] = b
            elif refs:
                sc = precoordinate(ref, concept, refs)
                out[cls] = sc
                kg.add((b, RDF.type, sc))
            else:
                out[cls] = concept
                kg.add((b, RDF.type, concept))

        elif kind == "referential":
            if concept is not None:
                nodes[cls] = concept; out[cls] = concept
            else:
                # genuinely-unspecified universal on a populated branch:
                # an honest existential ("some organ of …"), typed by its class
                b = BNode(); nodes[cls] = b; out[cls] = b
                kg.add((b, RDF.type, cls))

        else:  # structural — per-alarm blank typed by the class itself
            b = BNode(); nodes[cls] = b; out[cls] = b
            kg.add((b, RDF.type, cls))

        # Incoming link: concept→concept goes to vocab (dedup), else per-alarm KG
        parent_out, child_in = out[parent_cls], nodes[cls]
        target = ref if (_is_shared(parent_out) and _is_shared(child_in)) else kg
        target.add((parent_out, prop, child_in))

        # Marker co-types stamped by the connecting property (mda:targetType),
        # e.g. the message root (a Patient) is also typed mda:AlarmMessage.
        for extra in target_types.get(prop, ()):
            kg.add((child_in, RDF.type, extra))

    # Active classes: those with a node-column value or a present leaf's domain.
    # Waypoint ancestors are pulled in transitively by resolve_node.
    active = {cls for cls, col in node_columns.items() if cell(col) is not None}
    active |= {dcls for dcls, _, col, _, _ in leaf_specs if cell(col) is not None}
    for cls in active:
        resolve_node(cls)

    # Attach leaf properties (identity leaves already folded into the concept)
    for dcls, prop, col, role, scheme in leaf_specs:
        if role == "identity":
            continue
        v = cell(col)
        if v is None:
            continue
        resolve_node(dcls)
        kg.add((nodes[dcls], prop, resolve(scheme, v, index, col)))


def build_graphs(df: pd.DataFrame, index: dict, tree: dict, node_kind: dict,
                 node_columns: dict, leaf_specs: list, target_types: dict):
    """Return (kg, ref): per-alarm particulars, and deduplicated universals."""
    kg, ref = Graph(), Graph()
    for g in (kg, ref):
        g.bind("alarmtype", ALARMTYPE)
        g.bind("mda", MDA)
        g.bind("skos", SKOS)
        for prefix, base_uri in COLUMN_SCHEMES.values():
            g.bind(prefix, Namespace(base_uri))

    failed = []
    for i, row in df.iterrows():
        try:
            build_alarmtype_triples(row, kg, ref, index, tree,
                                    node_kind, node_columns, leaf_specs, target_types)
        except KeyError as e:
            failed.append(f"  Row {i + 2}: {e}")
    if failed:
        print("\n[WARN]  Rows skipped:")
        for line in failed:
            print(line)
    return kg, ref


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    # 1. Load the hand-maintained base files
    onto = Graph()
    onto.parse(ONTOLOGY_PATH, format="turtle")
    base = Graph()
    base.parse(VOCAB_BASE_PATH, format="turtle")

    # 2. Derive the nesting tree from the ontology and show it
    tree = derive_class_tree(onto, ROOT_CLASS)
    for line in format_tree(tree, ROOT_CLASS):
        print(f"[tree]   {line}")

    # 3. Read the alarm type definitions
    df = pd.read_csv(CSV_PATH, sep=";", dtype=str)
    df.columns = df.columns.str.strip()
    columns = [c for c in df.columns if c in COLUMN_SCHEMES]
    print(f"[csv]    Read {len(df)} row(s) from {CSV_PATH.name}; "
          f"vocabulary columns: {', '.join(columns)}")
    if LABEL_COLUMN not in df.columns:
        raise ValueError(f"CSV is missing the required label column '{LABEL_COLUMN}'.")
    unmapped = [c for c in df.columns if c not in COLUMN_SCHEMES and c != LABEL_COLUMN]
    if unmapped:
        print(f"[WARN]   Column(s) IGNORED — no COLUMN_SCHEMES mapping: {', '.join(unmapped)}")
    validate_notations(df, columns)

    # 4. Derive per-column attachment bindings, plus node-kind / leaf-role
    bindings = derive_bindings(onto, columns)
    stateful = set(onto.subjects(MDA.nodeKind, MDA.Stateful))
    node_columns, node_kind, leaf_specs = {}, {}, []
    for col in columns:
        kind, prop, cls, scheme = bindings[col]
        if kind == "node":
            node_columns[cls] = col
            marker = next((o for o in onto.objects(cls, MDA.nodeKind) if o in KIND_OF), None)
            node_kind[cls] = KIND_OF.get(marker, "referential")
        else:
            if any(str(o).lower() == "true" for o in onto.objects(prop, MDA.refinesUniversalIdentity)):
                role = "identity"
            elif cls in stateful:
                role = "state"
            else:
                role = "plain"
            leaf_specs.append((cls, prop, col, role, scheme))
    for col in columns:
        kind, prop, cls, _ = bindings[col]
        if kind == "node":
            how = f"{node_kind[cls]:12s} node on {_local(cls)}"
        else:
            role = next(r for c, p, cc, r, s in leaf_specs if cc == col)
            how = f"leaf {_local(prop)} ({role}) on {_local(cls)}"
        print(f"[bind]   {col:<24} → {how}")

    # Marker co-types stamped on nodes reached by a property (mda:targetType)
    target_types = {}
    for prop, extra in onto.subject_objects(MDA.targetType):
        target_types.setdefault(prop, []).append(extra)

    # 5. Vocabulary expansion — SKOS stubs for missing notations
    index     = build_notation_index(base)
    missing   = collect_missing(df, columns, bindings, index)
    vocab_out = build_vocab_graph(missing, bindings, base)
    print(f"[vocab]  {len(missing)} generated concept stub(s)")

    # 6. KG expansion — particulars → kg_generated; universals → vocab_generated
    index         = build_notation_index(base, vocab_out)
    kg_out, ref_out = build_graphs(df, index, tree, node_kind, node_columns,
                                   leaf_specs, target_types)
    for t in ref_out:                     # merge the deduplicated universal graph
        vocab_out.add(t)

    OUTCOME_DIR.mkdir(exist_ok=True)
    vocab_out.serialize(destination=str(VOCAB_OUT_PATH), format="turtle")
    kg_out.serialize(destination=str(KG_OUT_PATH), format="turtle")

    n_types = sum(1 for s in set(kg_out.subjects()) if str(s).startswith(str(ALARMTYPE)))
    n_bnodes = len({x for t in kg_out for x in t if isinstance(x, BNode)})
    print(f"[vocab]  {len(vocab_out)} triples ({len(ref_out)} universal) → "
          f"outcome/{VOCAB_OUT_PATH.name}")
    print(f"[kg]     {len(kg_out)} triples, {n_types} alarm type(s), "
          f"{n_bnodes} blank node(s) → outcome/{KG_OUT_PATH.name}")


if __name__ == "__main__":
    main()
