# P50 Annotation Axioms

## CARDIOHELP - Verbinding verbroken
Device: CardioHelp; Priority: Unknown; Department: Adult intensive care

None
---

## CARDIOHELP - pVen onder waarschuwingsgrens
Device: CardioHelp; Priority: Unknown; Department: Adult intensive care

None
---

## CRITICOOL - Verbinding verbroken
Device: Criticool; Priority: Hoog; Department: Neonatal intensive care, Paediatric intensive care

None
---

## DATEXOHMEDACOMVENTILATOR - MVexp High
Device: CarescapeR860; Priority: Hoog; Department: Paediatric intensive care

None
---

## DATEXOHMEDACOMVENTILATOR - Patient Disconnected
Device: CarescapeR860; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## DATEXOHMEDACOMVENTILATOR - Plimit Reached
Device: CarescapeR860; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## DATEXOHMEDACOMVENTILATOR - RR High
Device: CarescapeR860; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## DATEXOHMEDACOMVENTILATOR - VTexp High
Device: CarescapeR860; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## EDWARDS - Verbinding verbroken
Device: Edwards; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## HULBUS - 345
Device: LeoniPlus; Priority: Hoog; Department: Neonatal intensive care

<!-- axioms: -->

---

## HULBUS - Leak too high
Device: LeoniPlus; Priority: Hoog; Department: Neonatal intensive care

<!-- axioms: -->

---

## HULBUS - Vte high
Device: LeoniPlus; Priority: Hoog; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Air temperature high
Device: BabyLeo; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Air temperature low
Device: BabyLeo; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Check patient
Device: BabyLeo; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Humidity Sensor inoperable
Device: BabyTherm; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Humidity low
Device: BabyLeo, BabyTherm, Caleo; Priority: Laag; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Mattress temperature  setting deviation
Device: BabyTherm, Caleo; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Radiant heater after 15 mins. operation
Device: Caleo; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Slagvolume hoog
Device: Medibus; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## MEDIBUS - Verbinding verbroken
Device: Medibus; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## MEDIBUS - Verbinding verbroken
Device: BabyLeo, BabyTherm, Caleo; Priority: Hoog; Department: Neonatal intensive care

<!-- axioms: -->

---

## MEDIBUS - Volume niet constant
Device: Medibus; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## Monitor - ART statische druk
Device: DraegerMonitor; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## Monitor - Hoge ARTmean
Device: DraegerMonitor; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## Monitor - Lage ARTmean
Device: DraegerMonitor; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## Monitor - Lage SpO2
Device: DraegerMonitor; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## Monitor - SpO2 sensor uit
Device: DraegerMonitor; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - ABP verkleinen
Device: Philipsmonitor; Priority: Laag; Department: Neonatal intensive care, Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - CO2 wzig schaal l
Device: Philipsmonitor; Priority: Laag; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Desaturatie 
Device: Philipsmonitor; Priority: Hoog; Department: Neonatal intensive care, Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Extreme Tachy
Device: Philipsmonitor; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - HF hoog
Device: Philipsmonitor; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Lage hartfreq.
Device: Philipsmonitor; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Niet te leren ECG
Device: Philipsmonitor; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Resp elektr.los
Device: Philipsmonitor; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - SpO2 geen pols
Device: Philipsmonitor; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - SpO2 hoog
Device: Philipsmonitor; Priority: Medium; Department: Neonatal intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - SpO2 laag 
Device: Philipsmonitor; Priority: Medium; Department: Neonatal intensive care, Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - SpO2 lage PFI
Device: Philipsmonitor; Priority: Laag; Department: Paediatric intensive care

<!-- axioms: -->

---

## PHILIPSMONITOR - Storing in SpO2
Device: Philipsmonitor; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## PRISMAFLEX - Algemene systeemfout 
Device: Prismax; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## SERVOI - Ademfrequentie: Hoog
Device: ServoI; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOI - Exp. minuutvolume
Device: ServoI; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOI - Verbinding verbroken
Device: ServoI; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOU - Ademfrequentie hoog
Device: ServoU; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOU - Ademfrequentie hoog
Device: ServoU; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## SERVOU - Ademfrequentie laag
Device: ServoU; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOU - Beademingsdruk hoog
Device: ServoU; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## SERVOU - Exp. minuutvol. laag
Device: ServoU; Priority: Unknown; Department: Adult intensive care

<!-- axioms: -->

---

## SERVOU - Exp. minuutvol. laag
Device: ServoU; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## SERVOU - PEEP laag
Device: ServoU; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

## SERVOU - Volume uit blokkade
Device: ServoU; Priority: Laag; Department: Paediatric intensive care

<!-- axioms: -->

---

## TRILOGY - 0x79
Device: Trilogy; Priority: Hoog; Department: Paediatric intensive care

<!-- axioms: -->

---

## TRILOGY - Netspanning afwezig
Device: Trilogy; Priority: Medium; Department: Paediatric intensive care

<!-- axioms: -->

---

